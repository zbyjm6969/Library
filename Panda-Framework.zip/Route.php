<?php
/**
 * 只解析从浏览器发送过来的请求,对应到相应的module/controller/action
 *如果请求的是默认的controller和默认的action，如果要用rewrite来传参，则不能省略controller,和action例如  /index/index/30
 */
class Route
{
	/**
	 * 单例对象
	 *
	 * @var Route
	 */
	private static $instance=null;
	/**
	 * 模块名称
	 *
	 * @var string
	 */
	public $_module;
	
	/**
	 * 
	 *控制器名称
	 * @var string
	 */
	public $_controller;
	
	/**
	 * 
	 *
	 * @var string
	 */
	public $_action;
	
	/**
	 * 通过rewrite传递的参数
	 *
	 * @var array
	 */
	public $_param;
	
	/**
	 * 获取单例对象
	 *
	 * @return Route
	 */
	public static  function getInstance()
	{
		if(self::$instance===null)
		{
			$class=__CLASS__;
			self::$instance=new $class();
		}
		return self::$instance;
	}
	
	/**
	 * 构造函数,只有单例,如果有多个会引发异常
	 *
	 */
	public function __construct()
	{
		if(self::$instance!==null)
		{
			throw new Exception("Route is created!");
		}
	}
	
	/**
	 * 取得网站相对根目录的路径,例如apache的路径是d:/www,而网站的路径是d:/www/btv，则返回/btv/
	 * 调用该方法之前要先声明常量ROOT_DIR否则抛出异常
	 *
	 * @return string
	 */
	public function getBaseURL()
	{
		if(defined('BASE_URL'))
		{
			return BASE_URL;
		}
		if(!defined('ROOT_DIR'))
		{
			throw new Exception('常量ROOT_DIR没有定义');
		}
		
		$base_url=substr(ROOT_DIR,strlen($_SERVER['DOCUMENT_ROOT']));
		$base_url=str_replace("\\","/",$base_url);
		if(strlen($base_url)<1||$base_url{0}!='/')
		{
			$base_url="/".$base_url;
		}
		if($base_url{strlen($base_url)-1}!='/')
		{
			$base_url.="/";
		}
		return $base_url;
	}
	
	/**
	 * 解析rewrite的uri,映射到controller里去
	 *
	 */
	public function parseRequestURI()
	{
		$uri=$_SERVER['REQUEST_URI'];
		if(strpos($uri,".".URL_SUFFIX)==strlen($uri)-strlen(".".URL_SUFFIX)&&strpos($uri,".".URL_SUFFIX)>0)
		{
			$uri=substr($uri,0,strlen($uri)-strlen(".".URL_SUFFIX));
		}
		
		$uri=substr($uri,strlen($this->getBaseURL()));
		
		$uri=parse_url($uri);
		$uri=$uri['path'];
		$uri=explode("/",$uri);
		
		if(!empty($uri)&&strlen($uri[count($uri)-1])==0)
		{
			array_pop($uri);
		}
		
		if(empty($uri)||empty($uri[0]))
		{
			$this->_module='default';
			$this->_controller='index';
			$this->_action='index';
			return ;
		}
		$modules=Registry::getInstance()->get('modules');
		if(key_exists(strtolower($uri[0]),$modules))
		{
			$this->_module=strtolower($uri[0]);
			array_shift($uri);
		}
		else 
		{
			$this->_module='default';
		}
		if(!empty($uri[0]))
		{
			$this->_controller=$uri[0];
			array_shift($uri);
		}
		else 
		{
			$this->_controller='index';
		}
		if(!empty($uri[0]))
		{
			$this->_action=$uri[0];
			array_shift($uri);
		}
		else 
		{
			$this->_action='index';
		}
		$this->_param=$uri;
	}
	
	/**
	 * 进行路由派发,controller的类文件名要小写,后面的Controller首字母要大写,例如indexController.php
	 * 也可以直接调用restful文件,
	 *
	 * @param string $module
	 * @param string $controller
	 * @param string $action
	 * @param array $param
	 */
	public function dispatch($module='',$controller='',$action=null,$param=null)
	{
		if(is_null($action))
		{
			$this->parseRequestURI();
			$module=$this->_module;
			$controller=$this->_controller;
			$action=$this->_action;
			$param=$this->_param;
		}

		$modules=Registry::getInstance()->get('modules');
		$controller_file=ROOT_DIR.$modules[$module]."/controller/".strtolower($controller)."Controller.php";
		
		$path_info=pathinfo($_SERVER['PATH_INFO']);
		if(strtolower($path_info['extension'])=='php'&&is_file(ROOT_DIR.$_SERVER['PATH_INFO']))
		{
			
			include_once(ROOT_DIR.$_SERVER['PATH_INFO']);
			return ;
		}
		
		$controller_name=$controller."Controller";
		if(file_exists(ROOT_DIR.$modules[$module]."/rest/".$controller.".php"))
		{
			include(ROOT_DIR.$modules[$module]."/rest/".$controller.".php");
			return ;
		}
		if(!file_exists($controller_file))
		{
			if(Registry::getInstance()->isRegisted('404'))
			{
				$error_404=Registry::getInstance()->get('404');
				
				if($module==$error_404['module']&&$controller==$error_404['controller']&&$action==$error_404['action'])
				{
					throw new Exception('404页面不存在'.$error_404['module']."/".$error_404['controller']."/".$error_404['action']);
					return ;
				}
				$this->dispatch($error_404['module'],$error_404['controller'],$error_404['action']);
			}
			else 
			{
				header("HTTP/1.0 404 Not Found");
				exit();
				throw new Exception('controller类文件'.$controller_file."不存在");
				return ;
			}
		}
		
		include_once($controller_file);
		$controller_obj=new $controller_name($module,$controller,$action);
		if(is_callable(array(&$controller_obj,'init')))
		{
			$controller_obj->init();
		}
		
		if(is_callable(array(&$controller_obj,$action."Action")))
		{
			
			call_user_func_array(array(&$controller_obj,$action."Action"),$param);
		}
		else 
		{
			
			if(Registry::getInstance()->isRegisted('404'))
			{
				$error_404=Registry::getInstance()->get('404');
				if($module==$error_404['module']&&$controller==$error_404['controller']&&$action==$error_404['action'])
				{
					throw new Exception('404页面不存在'.$error_404['module']."/".$error_404['controller']."/".$error_404['action']);
					return ;
				}
				
				$this->dispatch($error_404['module'],$error_404['controller'],$error_404['action']);
			}
			else 
			{
				throw new Exception('controller类文件'.$controller_file."不存在方法{$action}Action");
				return ;
			}
		}
		
		
	}
}