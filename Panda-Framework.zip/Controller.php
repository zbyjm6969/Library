<?php
/**
 * 控制器父类,其子类不能有构造函数,每个控制器包含有一个view对象,可以用来设置给页面传值
 *
 */
class Controller
{
	/**
	 * 模块名
	 *
	 * @var string
	 */
	public $_module;
	
	/**
	 * 控制器名,不包括后缀的Controller
	 *
	 * @var string
	 */
	public $_controller;
	
	/**
	 * 动作名,不包括后缀的Action
	 *
	 * @var string
	 */
	public $_action;
	
	/**
	 * 每个controller对应一个视图对象
	 *
	 * @var View
	 */
	public $_view;
	
	/**
	 * 构造函数,子类不能有构造函数,如果需要统一初始化的话,应该采用init函数
	 *
	 * @param string $module
	 * @param string $controller   不带后缀Controller
	 * @param string $action     不带后缀Action
	 */
	public function __construct($module,$controller,$action)
	{
		$this->_module=$module;
		$this->_controller=$controller;
		$this->_action=$action;
		$this->_view=new View();
	}
	
	/**
	 * 设置布局类型,布局文件在相对应的模块的layout文件夹下,
	 *
	 * @param string $layout
	 * @param string $module   为空的话,则是当前控制器所在的模块
	 */
	public function setLayout($layout,$module="")
	{
		$modules=Registry::getInstance()->get('modules');
		if(empty($module))
		{
			$module=$this->_module;
		}
		$module=strtolower($module);
		$layout_file=ROOT_DIR.$modules[$module]."/layout/".$layout.".php";
		$this->_view->setLayout($layout_file);
	}
	
	/**
	 * 控制器设置完数据后,显示页面.
	 *
	 * @param string $action  默认当前的action无后缀
	 * @param string $controller   默认当前的控制器无后缀
	 * @param string $module   默认当前的模块
	 */
	public function display($action="",$controller="",$module="")
	{
		$view_file="";
		$modules=Registry::getInstance()->get('modules');
		if(empty($module))
		{
			$module=$this->_module;
		}
		if(empty($controller))
		{
			$controller=$this->_controller;
		}
		if(empty($action))
		{
			$action=$this->_action;
		}
		$module=strtolower($module);
		$controller=strtolower($controller);
		$action=strtolower($action);
		$view_file=ROOT_DIR.$modules[$module]."/view/".$controller."/".$action.".php";
		$this->_view->display($view_file);
	}
}