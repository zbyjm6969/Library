<?php
/**
 * 本架构的model的观察者接口,在model层进行update,delete,insert后,所需要调用的对象接口
 *
 */
interface IModelObserver
{
	/**
	 * 更新时调用,如果是基于单条主键更新,则把主键传递过来
	 *
	 * @param string $_database_name
	 * @param string $_table_name
	 * @param array $primarys
	 */
	public function onUpdate($_database_name,$_table_name,$primarys=array());
	
	/**
	 * 删除时调用,如果是基于单条主键删除,则把主键传递过来
	 *
	 * @param string $_database_name
	 * @param string $_table_name
	 * @param array $primarys
	 */
	public function onDelete($_database_name,$_table_name,$primarys=array());
	
	/**
	 * 插入时调用,传递所有的主键和插入的bean的数据.
	 *
	 * @param string $_database_name
	 * @param string $_table_name
	 * @param Object $data  把插入的model对象传递过来
	 */
	public function onInsert($_database_name,$_table_name,$data="");
}