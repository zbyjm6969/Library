<?php
class Registry
{
	/**
	 * 单例对象
	 *
	 * @var Registry
	 */
	private static $instance=null;
	/**
	 * 存储注册数据的数组
	 *
	 * @var array
	 */
	private $registry_array;
	/**
	 * 获取单例对象
	 *
	 * @return Registry
	 */
	public static  function getInstance()
	{
		if(self::$instance===null)
		{
			$class=__CLASS__;
			self::$instance=new $class();
		}
		return self::$instance;
	}
	
	/**
	 * 构造函数,只有单例,如果有多个会引发异常
	 *
	 */
	public function __construct()
	{
		if(self::$instance!==null)
		{
			throw new Exception("Registry is created!");
		}
		else 
		{
			$this->registry_array=array();
		}
	}
	
	/**
	 * 是否有注册
	 *
	 * @param string $key
	 * @return bool
	 */
	public function  isRegisted($key)
	{
		if(array_key_exists($key,$this->registry_array))
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
	
	/**
	 * 注册一个值
	 *
	 * @param string $key
	 * @param mixed $value
	 * @param bool $cover  是否进行覆盖
	 * @return bool
	 */
	public function set($key,$value,$cover=false)
	{
		if($this->isRegisted($key))
		{
			if($cover)
			{
				$this->registry_array[$key]=$value;
				return true;
			}
			else 
			{
				return false;
			}
		}
		else 
		{
			$this->registry_array[$key]=$value;
			return true;
		}
	}
	
	/**
	 * 获取注册的值
	 *
	 * @param string $key
	 * @return mixed
	 */
	public function get($key)
	{
		if($this->isRegisted($key))
		{
			return $this->registry_array[$key];
		}
		else 
		{
			return null;
		}
	}
	
	
	/**
	 * 取消注册
	 *
	 * @param string $key
	 * @return bool
	 */
	public  function unRegistry($key)
	{
		if($this->isRegisted($key))
		{
			unset($this->registry_array[$key]);
			return true;
		}
		else 
		{
			return false;
		}
	}
}