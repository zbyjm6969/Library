<?php
/**
 * 把数组转化为指定的对象,并进行递归,数字键的数组只支持一维,即array(1=>array(1=>array('id'=>1)))不可以,
 * arrayToObject(array('name'=>'frchen','id'=>'1','book'=>array('2'=>array('book_name'=>'aaaa'),array('book_name'=>'bbb'))),$m)
 *
 * @param array $array
 * @param Object $obj
 * @return Object
 */
function arrayToObject($array,$obj)
{
	foreach ($array as $key=>$value)
	{
		if(property_exists($obj,$key))
		{
			if(is_array($value))
			{
				$new_obj=getObjectByKey($key,$obj);
				$key1=key($value);
				if(is_integer($key1)&&!empty($value))
				{
					$temp=array();
					foreach ($value as $key1=>$value1)
					{
						$new_obj=getObjectByKey($key,$obj);
						$temp[$key1]=arrayToObject($value1,$new_obj);
					}
					$obj->$key=$temp;
				}
				else
				{
					$new_obj=arrayToObject($value,$new_obj);
					$obj->$key=$new_obj;
				}
			}
			else
			{
				$obj->$key=$value;
			}
		}

	}

	return $obj;

}
/**
 * 把数组转化为xml,数字索引只支持一维,数字索引和字符索引不能混合
 *
 * @param array $array
 * @param array $text_columns
 * @return string
 */
function arrayToXML($array,$text_columns=array())
{

	$str_xml="";
	if(is_array($array)&&!empty($array))
	{
		$has_number_key=false;
		foreach ($array as $key=>$value)
		{
			$parent_key=@func_get_arg(3);

			if(is_int($key))
			{
				$has_number_key=true;
				if(is_integer($parent_key))
				{
					throw new Exception('数字索引只支持一维');
				}
				if(empty($parent_key))
				{
					$parent_key=$key;
				}
				else
				{
					if($parent_key{strlen($parent_key)-1}=='s')
					{
						$parent_key=substr($parent_key,0,strlen($parent_key)-1);
					}
				}

				$str_xml.="<$parent_key>".arrayToXML($value,$text_columns,$key,$parent_key)."</$parent_key>";
			}
			else
			{
				if($has_number_key)
				{
					throw new Exception('数字索引和字符索引不能混合');
				}

				$parent_key=$key;

				/*$key_temp='';
				if(is_array($value))
				{
				$key_temp=key($value);
				}
				if(is_integer($key_temp))
				{
				$str_xml.=arrayToXML($value,&$text_columns,$key,$parent_key);
				}
				else
				{
				$str_xml.="<$key>".arrayToXML($value,&$text_columns,$key,$parent_key)."</$key>";
				}*/
				$str_xml.="<$key>".arrayToXML($value,$text_columns,$key,$parent_key)."</$key>";
			}
		}
	}
	else
	{
		$key=func_get_arg(2);
		/*if(in_array($key,$text_columns))
		{
		return '<![CDATA['.$array.']]>';
		}*/
		if(strpos($array,'<')!==false||strpos($array,'&')!==false)
		{
			return '<![CDATA['.$array.']]>';
		}
		if(is_array($array)&&empty($array))
		{
			return '';
		}
		return $array;
	}
	return $str_xml;
}

/**
 * 把数组转化成可以通过fsockopen,post上去的字符串,可以支持多维数组,并支持其中的key
 *
 * @param array $array
 * @return string
 */
function arrayToPostString($array,$keys=array())
{
	$str="";
	if(!empty($array)&&is_array($array))
	{
		foreach ($array as $key=>$value)
		{
			$temp_keys=$keys;
			$temp_keys[]=$key;
			if(is_array($value))
			{
				$str.=arrayToPostString($value,$temp_keys);
			}
			else
			{
				$key=$temp_keys[0];
				for ($i=1,$c=count($temp_keys);$i<$c;$i++)
				{
					$key.='['.$temp_keys[$i].']';
				}
				$str.='&'.$key.'='.urlencode($value);
			}
		}
	}
	else if(!empty($array))
	{
		$key=$keys[0];
		for ($i=1,$c=count($temp_keys);$i<$c;$i++)
		{
			$key.='['.$temp_keys[$i].']';
		}
		return '&'.$key.'='.urlencode($value);
		return $str;
	}
	return $str;
}
/**
 * 把xml转化为数组,支持带有冒号的标签
 *
 * @param xml_string $contents
 * @param int $get_attributes
 * @param string $priority
 * @return array
 */
function xml2array($contents, $get_attributes=1, $priority = 'tag') {
	if(!$contents) return array();

	if(!function_exists('xml_parser_create')) {
		//print "'xml_parser_create()' function not found!";
		return array();
	}

	//Get the XML parser of PHP - PHP must have this module for the parser to work
	$parser = xml_parser_create('');
	xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8"); # http://minutillo.com/steve/weblog/2004/6/17/php-xml-and-character-encodings-a-tale-of-sadness-rage-and-data-loss
	xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
	xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
	xml_parse_into_struct($parser, trim($contents), $xml_values);
	xml_parser_free($parser);

	if(!$xml_values) return;//Hmm...

	//Initializations
	$xml_array = array();
	$parents = array();
	$opened_tags = array();
	$arr = array();

	$current = &$xml_array; //Refference

	//Go through the tags.
	$repeated_tag_index = array();//Multiple tags with same name will be turned into an array
	foreach($xml_values as $data) {
		unset($attributes,$value);//Remove existing values, or there will be trouble

		//This command will extract these variables into the foreach scope
		// tag(string), type(string), level(int), attributes(array).
		extract($data);//We could use the array by itself, but this cooler.

		$result = array();
		$attributes_data = array();

		if(isset($value)) {
			if($priority == 'tag') $result = $value;
			else $result['value'] = $value; //Put the value in a assoc array if we are in the 'Attribute' mode
		}

		//Set the attributes too.
		if(isset($attributes) and $get_attributes) {
			foreach($attributes as $attr => $val) {
				if($priority == 'tag') $attributes_data[$attr] = $val;
				else $result['attr'][$attr] = $val; //Set all the attributes in a array called 'attr'
			}
		}

		//See tag status and do the needed.
		if($type == "open") {//The starting of the tag '<tag>'
			$parent[$level-1] = &$current;
			if(!is_array($current) or (!in_array($tag, array_keys($current)))) { //Insert New tag
				$current[$tag] = $result;
				if($attributes_data) $current[$tag. '_attr'] = $attributes_data;
				$repeated_tag_index[$tag.'_'.$level] = 1;

				$current = &$current[$tag];

			} else { //There was another element with the same tag name

				if(isset($current[$tag][0])) {//If there is a 0th element it is already an array
					$current[$tag][$repeated_tag_index[$tag.'_'.$level]] = $result;
					$repeated_tag_index[$tag.'_'.$level]++;
				} else {//This section will make the value an array if multiple tags with the same name appear together
					$current[$tag] = array($current[$tag],$result);//This will combine the existing item and the new item together to make an array
					$repeated_tag_index[$tag.'_'.$level] = 2;

					if(isset($current[$tag.'_attr'])) { //The attribute of the last(0th) tag must be moved as well
						$current[$tag]['0_attr'] = $current[$tag.'_attr'];
						unset($current[$tag.'_attr']);
					}

				}
				$last_item_index = $repeated_tag_index[$tag.'_'.$level]-1;
				$current = &$current[$tag][$last_item_index];
			}

		} elseif($type == "complete") { //Tags that ends in 1 line '<tag />'
			//See if the key is already taken.
			if(!isset($current[$tag])) { //New Key
				$current[$tag] = $result;
				$repeated_tag_index[$tag.'_'.$level] = 1;
				if($priority == 'tag' and $attributes_data) $current[$tag. '_attr'] = $attributes_data;

			} else { //If taken, put all things inside a list(array)
				if(isset($current[$tag][0]) and is_array($current[$tag])) {//If it is already an array...

					// ...push the new element into that array.
					$current[$tag][$repeated_tag_index[$tag.'_'.$level]] = $result;

					if($priority == 'tag' and $get_attributes and $attributes_data) {
						$current[$tag][$repeated_tag_index[$tag.'_'.$level] . '_attr'] = $attributes_data;
					}
					$repeated_tag_index[$tag.'_'.$level]++;

				} else { //If it is not an array...
					$current[$tag] = array($current[$tag],$result); //...Make it an array using using the existing value and the new value
					$repeated_tag_index[$tag.'_'.$level] = 1;
					if($priority == 'tag' and $get_attributes) {
						if(isset($current[$tag.'_attr'])) { //The attribute of the last(0th) tag must be moved as well

							$current[$tag]['0_attr'] = $current[$tag.'_attr'];
							unset($current[$tag.'_attr']);
						}

						if($attributes_data) {
							$current[$tag][$repeated_tag_index[$tag.'_'.$level] . '_attr'] = $attributes_data;
						}
					}
					$repeated_tag_index[$tag.'_'.$level]++; //0 and 1 index is already taken
				}
			}

		} elseif($type == 'close') { //End of tag '</tag>'
			$current = &$parent[$level-1];
		}
	}

	return($xml_array);
}
/**
 * 把xml字符串转化为相对应的数组

 * 
 * @param string $xml
 * @return array
 */
function xmlToArray($xml)
{
	$data=array();

	if(!is_a($xml,'SimpleXMLIterator'))
	{
		$xml=new SimpleXMLIterator($xml);
	}
	if($xml->count())
	{
		$has_num_child=false;
		foreach ($xml as $key=>$value)
		{
			if($value->count())
			{
				$temp=xmlToArray($value,$key);
			}
			else
			{
				$temp=(string)$value;
			}
			if(key_exists($key,$data))
			{
				$has_num_child=true;
				$key_first='';
				if(is_array($data[$key]))
				{
					$key_first=key($data[$key]);
				}
				$temp_data=$data[$key];
				if(is_integer($key_first))
				{
					$data[$key][]=$temp;
				}
				else
				{
					$temp1=$data[$key];
					$data[$key]=array();
					$data[$key][]=$temp1;
					$data[$key][]=$temp;
				}
			}
			else
			{

				$data[$key]=$temp;
			}
		}
		$key_first=key($data);
		$parent_key=@func_get_arg(1);
		if($has_num_child)
		{


			if($key_first.'s'==$parent_key)
			{
				$data=$data[$key_first];
			}
		}
		else if($key_first.'s'==$parent_key)
		{
			$data=array($data[$key_first]);
		}

	}
	else
	{
		throw new Exception('XML解析出错');
	}
	return $data;
}



/**
 * 通过组数的键名来取相对应的类对象
 *
 * @param string $key
 * @param Object $parent_obj
 * @return Object
 */
function getObjectByKey($key,$parent_obj)
{
	if(method_exists($parent_obj,'getSubObject')&&$parent_obj->getSubObject($key)!==false)
	{
		return $parent_obj->getSubObject($key);
	}
	else
	{

		if(!class_exists($key))
		{
			$key=substr($key,0,strlen($key)-1);
		}
		return new $key();
	}
}

/**
 * 把object进行递归转为数组
 *
 * @param Object $obj
 * @return array
 */
function objectToArray($obj)
{
	if(is_array($obj))
	{
		$vars=$obj;
	}
	else
	{
		$vars=get_object_vars($obj);
	}
	if(!empty($vars))
	{
		foreach ($vars as $key=>$value)
		{
			if(is_array($value))
			{
				$value=objectToArray($value);
			}
			if(is_object($value))
			{
				$value=objectToArray($value);
			}
		}
	}
	return $vars;
}
/**
 * 把对象转化为xml字符串
 *
 * @param Object $obj
 * @return string   XML string
 */
function objectToXML($obj)
{
	$array=objectToArray($obj);
	return arrayToXML($array);
}


/**
 * 把json对象还原为数组,json为json_deconde后的对象
 *
 * @param Object $json_object
 * @return array
 */
function jsonToArray($json_object)
{
	if(is_array($json_object))
	{
		$temp_array=array();
		if(!empty($json_object))
		{
			foreach ($json_object as $key=>$value)
			{
				$temp_array[$key]=jsonToArray($value);
			}
		}
		return $temp_array;
	}
	else if(get_class($json_object)=='stdClass')
	{
		$vars=get_object_vars($json_object);
		$temp_array=array();
		if(!empty($vars))
		{
			foreach ($vars as $key=>$value)
			{
				$temp_array[$key]=jsonToArray($value);
			}
		}
		return $temp_array;
	}
	else
	{
		return $json_object;
	}
}
/**
 * 把json对象递归转化为相应的对象,数字键索引只支持一维,不能连续多维
 *
 * @param Object $json_object   经过json_decode()的json对象
 * @param Object $obj           相对应的对象
 * @return Object
 */

function jsonToObject($json_object,$obj)
{
	$vars=get_object_vars($json_object);
	if(!empty($vars))
	{
		foreach ($vars as $key=>$value)
		{
			if(property_exists($obj,$key))
			{
				if(is_array($value))
				{
					$temp_value=array();
					if(!empty($value))
					{
						foreach ($value as $key1=>$value1)
						{
							if(is_array($value1))
							{
								throw new Exception('不能嵌套多维数字键索引');
							}
							$sub_obj=getObjectByKey($key,$obj);
							$sub_obj=jsonToObject($value1,$sub_obj);

							$temp_value[$key1]=$sub_obj;
						}
					}
					$obj->$key=$temp_value;
				}
				else if(get_class($value)=='stdClass')
				{
					$sub_obj=getObjectByKey($key,$obj);
					$sub_obj=jsonToObject($value,$sub_obj);
					$obj->$key=$sub_obj;
				}
				else
				{
					$obj->$key=$value;
				}
			}
		}
	}
	return $obj;
}

/**
 * 把json对象转换为xml字符串
 *
 * @param Object $json_object
 * @return string  xml string
 */
function jsonToXML($json_object)
{
	$json_object=jsonToArray($json_object);
	$json_object=arrayToXML($json_object);
	return $json_object;
}




/**
 * 把xml字符串转化为json字符串
 *
 * @param string $xml
 * @return string  json_encode过的字符串
 */
function xmlToJson($xml)
{
	$xml_array=xmlToArray($xml);
	$xml=json_encode($xml_array);
	return $xml;
}


/**
 * 把xml转换为相对应的对象
 *
 * @param string $xml
 * @param Object $obj
 * @return Object
 */
function xmlToObject($xml,$obj)
{
	$xml_array=xmlToArray($xml);

	$obj=arrayToObject($xml_array,$obj);
	return $obj;
}

/**
 * 用fsockopen来获取内容,支持post,get,put,
 *
 * @param string $request_type      POST,GET,PUT
 * @param string|array $param 如果$files不为空的话,则传进来的是数组,空的话则为字符串
 * @param string $host
 * @param string $path
 * @param int $port
 * @param int $time_out
 * @param array $files $_FILES['key']为键名,文件名为键值
 * @return string
 */
function getContentsBySockOpen($request_type,$param,$host,$path,$port=80,$time_out=5,$files=array())
{
	$errno="";
	$errstr="";
	

	$fp = fsockopen($host, $port, $errno, $errstr, $time_out);

	if (!$fp) {
		echo "$errstr ($errno)<br />\n";
	} else {
		$out = "$request_type ".$path." HTTP/1.1\r\n";
		$out .= "Host: ".$host."\r\n";
		$out .= "Connection: Close\r\n";
		if(!empty($files))
		{
			srand((double)microtime()*1000000);
			$boundary = "---------------------".substr(md5(rand(0,32000)),0,10);
			$out.="Content-type: multipart/form-data, boundary=$boundary\r\n";
		}
		else
		{
			$out.= "Content-type: application/x-www-form-urlencoded\r\n";
		}
		$out.= "User-Agent: Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.2.1) Gecko/20021204\r\n";
		$out .= "Accept: text/xml,application/xml,application/xhtml+xml,text/json\r\n";
		if (!empty($_COOKIE))
		{
			$out.="Cookie: ";
			$cookies=array();
			foreach ($_COOKIE as $key=>$value)
			{
				$cookies[]=$key.'='.urlencode($value);
			}
			$out.=implode("; ",$cookies);
			$out.="\r\n";
		}
		$param_string="";
		if(empty($files)&&is_array($param))
		{
			exit(__FUNCTION__."参数错误");
		}

		if(!empty($param)&&is_array($param))
		{
			foreach($param as $key=>$value){
				$param_string .="--$boundary\r\n";
				$param_string .= "Content-Disposition: form-data; name=\"".$key."\"\r\n";
				$param_string .= "\r\n".$value."\r\n";
				$param_string .="--$boundary\r\n";
			}

			$param=$param_string;
		}
		$file_size=0;
		if(!empty($files))
		{
			foreach ($files as $key=>$value)
			{
				$file_type=pathinfo($value);
				$file_type=FileMimeType($file_type['extension']);
				$key1 = "--$boundary\r\nContent-Disposition: form-data; name=\"{$key}\"; filename=\"$value\"\r\nContent-Type: $file_type\r\n\r\n\r\n--$boundary\r\n";
				$file_size_temp=0;
				if(preg_match("/^http/ims",$value))
				{
					$file_size_temp=get_headers($value);
					
					for($i2=0,$c2=count($file_size_temp);$i2<$c2;$i2++)
					{
						if(strpos($file_size_temp[$i2],"Content-Length")===0)
						{
							$file_size_temp=substr($file_size_temp[$i2],16);
						}
					}
				}
				else 
				{
					$file_size_temp=filesize($value);
				}
				$file_size+=$file_size_temp;
				$file_size+=strlen($key1);
				$files[$key]=array($value,$file_type);
				
			}
			$file_size+=2;
		}
		//$out.="Content-Length: 0\r\n\r\n";
		$out.="Content-Length: ".(strlen($param)+$file_size)."\r\n\r\n";
		$out.=$param;
		fwrite($fp, $out);
		if(!empty($files))
		{
			$count_file=count($files);
			$i=0;
			foreach ($files as $key=>$value)
			{
				$i++;
				$file_type=$value[1];
				$value=$value[0];

				$key = "--$boundary\r\nContent-Disposition: form-data; name=\"{$key}\"; filename=\"$value\"\r\nContent-Type: $file_type\r\n\r\n";
				fwrite($fp,$key);
				$file_handle=fopen($value,"r");
				while (!feof($file_handle))
				{
					fwrite($fp,fread($file_handle,1024));
				}
				fclose($file_handle);
				if($i==$count_file)
				{
					$key="\r\n--$boundary--\r\n";
				}
				else
				{
					$key="\r\n--$boundary\r\n";
				}
				fwrite($fp,$key);
			}

		}
		$contents="";
		$count=0;
		while (!feof($fp)) {
			$contents.=fgets($fp, 128);
			if($count==0)
			{
				if(strpos($contents,"200")===false)
				{
					fclose($fp);
					throw new Exception('打开地址'.$host.":".$port.$path."出错");
				}
				if($time_out===1)
				{
					fclose($fp);
					return $contents;
				}
				$count++;
			}

		}

		fclose($fp);
		
		$contents=substr($contents,strpos($contents,"\r\n\r\n")+4);
		return $contents;
	}
}



function FileMimeType($file_ext)
{
	$types=unserialize('a:450:{s:3:"3dm";s:14:"x-world/x-3dmf";s:4:"3dmf";s:14:"x-world/x-3dmf";s:3:"qd3";s:14:"x-world/x-3dmf";s:4:"qd3d";s:14:"x-world/x-3dmf";s:1:"a";s:24:"application/octet-stream";s:3:"arc";s:24:"application/octet-stream";s:3:"arj";s:15:"application/arj";s:3:"bin";s:23:"application/x-macbinary";s:3:"com";s:10:"text/plain";s:4:"dump";s:24:"application/octet-stream";s:3:"exe";s:24:"application/octet-stream";s:3:"lha";s:17:"application/x-lha";s:3:"lhx";s:24:"application/octet-stream";s:3:"lzh";s:17:"application/x-lzh";s:3:"lzx";s:17:"application/x-lzx";s:1:"o";s:24:"application/octet-stream";s:3:"psd";s:24:"application/octet-stream";s:6:"saveme";s:24:"application/octet-stream";s:2:"uu";s:15:"text/x-uuencode";s:3:"zoo";s:24:"application/octet-stream";s:3:"aab";s:28:"application/x-authorware-bin";s:3:"aam";s:28:"application/x-authorware-map";s:3:"aas";s:28:"application/x-authorware-seg";s:3:"abc";s:12:"text/vnd.abc";s:4:"acgi";s:9:"text/html";s:3:"htm";s:9:"text/html";s:4:"html";s:9:"text/html";s:5:"htmls";s:9:"text/html";s:3:"htx";s:9:"text/html";s:5:"shtml";s:25:"text/x-server-parsed-html";s:3:"afl";s:15:"video/animaflex";s:2:"ai";s:22:"application/postscript";s:3:"eps";s:22:"application/postscript";s:2:"ps";s:22:"application/postscript";s:3:"aif";s:12:"audio/x-aiff";s:4:"aifc";s:12:"audio/x-aiff";s:4:"aiff";s:12:"audio/x-aiff";s:3:"aim";s:17:"application/x-aim";s:3:"aip";s:22:"text/x-audiosoft-intra";s:3:"ani";s:28:"application/x-navi-animation";s:3:"aos";s:53:"application/x-nokia-9000-communicator-add-on-software";s:3:"aps";s:16:"application/mime";s:3:"art";s:10:"image/x-jg";s:3:"asf";s:14:"video/x-ms-asf";s:3:"asx";s:21:"video/x-ms-asf-plugin";s:3:"asm";s:10:"text/x-asm";s:1:"s";s:10:"text/x-asm";s:3:"asp";s:8:"text/asp";s:2:"au";s:10:"audio/x-au";s:3:"snd";s:13:"audio/x-adpcm";s:3:"avi";s:15:"video/x-msvideo";s:3:"avs";s:15:"video/avs-video";s:5:"bcpio";s:19:"application/x-bcpio";s:2:"bm";s:9:"image/bmp";s:3:"bmp";s:19:"image/x-windows-bmp";s:3:"boo";s:16:"application/book";s:4:"book";s:16:"application/book";s:3:"boz";s:19:"application/x-bzip2";s:3:"bz2";s:19:"application/x-bzip2";s:3:"bsh";s:17:"application/x-bsh";s:2:"sh";s:16:"text/x-script.sh";s:4:"shar";s:18:"application/x-shar";s:2:"bz";s:18:"application/x-bzip";s:1:"c";s:8:"text/x-c";s:3:"c++";s:10:"text/plain";s:2:"cc";s:8:"text/x-c";s:4:"conf";s:10:"text/plain";s:3:"cxx";s:10:"text/plain";s:3:"def";s:10:"text/plain";s:1:"f";s:14:"text/x-fortran";s:3:"f90";s:14:"text/x-fortran";s:3:"for";s:14:"text/x-fortran";s:1:"g";s:10:"text/plain";s:1:"h";s:8:"text/x-h";s:2:"hh";s:8:"text/x-h";s:3:"idc";s:10:"text/plain";s:3:"jav";s:18:"text/x-java-source";s:4:"java";s:18:"text/x-java-source";s:4:"list";s:10:"text/plain";s:3:"log";s:10:"text/plain";s:3:"lst";s:10:"text/plain";s:1:"m";s:8:"text/x-m";s:3:"mar";s:10:"text/plain";s:2:"pl";s:18:"text/x-script.perl";s:4:"sdml";s:10:"text/plain";s:4:"text";s:17:"application/plain";s:3:"txt";s:10:"text/plain";s:3:"cpp";s:8:"text/x-c";s:3:"cat";s:29:"application/vnd.ms-pki.seccat";s:4:"ccad";s:21:"application/clariscad";s:3:"cco";s:19:"application/x-cocoa";s:3:"cdf";s:20:"application/x-netcdf";s:2:"nc";s:20:"application/x-netcdf";s:3:"cer";s:26:"application/x-x509-ca-cert";s:3:"crt";s:28:"application/x-x509-user-cert";s:3:"der";s:26:"application/x-x509-ca-cert";s:3:"cha";s:18:"application/x-chat";s:4:"chat";s:18:"application/x-chat";s:5:"class";s:24:"application/x-java-class";s:4:"cpio";s:18:"application/x-cpio";s:3:"cpt";s:17:"application/x-cpt";s:3:"crl";s:20:"application/pkix-crl";s:3:"csh";s:17:"text/x-script.csh";s:3:"css";s:8:"text/css";s:3:"dcr";s:22:"application/x-director";s:3:"dir";s:22:"application/x-director";s:3:"dxr";s:22:"application/x-director";s:5:"deepv";s:19:"application/x-deepv";s:3:"dif";s:10:"video/x-dv";s:2:"dv";s:10:"video/x-dv";s:2:"dl";s:10:"video/x-dl";s:3:"doc";s:18:"application/msword";s:3:"dot";s:18:"application/msword";s:3:"w6w";s:18:"application/msword";s:3:"wiz";s:18:"application/msword";s:4:"word";s:18:"application/msword";s:2:"dp";s:24:"application/commonground";s:3:"drw";s:20:"application/drafting";s:3:"dvi";s:17:"application/x-dvi";s:3:"dwf";s:13:"model/vnd.dwf";s:13:"drawing/x-dwf";s:5:"(old)";s:3:"dwg";s:11:"image/x-dwg";s:3:"dxf";s:15:"application/dxf";s:3:"svf";s:11:"image/x-dwg";s:2:"el";s:19:"text/x-script.elisp";s:3:"elc";s:17:"application/x-elc";s:28:"application/x-bytecode.elisp";s:6:"elisp)";s:9:"(compiled";s:6:"elisp)";s:3:"env";s:19:"application/x-envoy";s:3:"evy";s:17:"application/envoy";s:2:"es";s:22:"application/x-esrehber";s:3:"etx";s:13:"text/x-setext";s:3:"f77";s:14:"text/x-fortran";s:3:"fdf";s:19:"application/vnd.fdf";s:3:"fif";s:9:"image/fif";s:3:"fli";s:11:"video/x-fli";s:3:"flo";s:13:"image/florian";s:6:"turbot";s:13:"image/florian";s:3:"flx";s:21:"text/vnd.fmi.flexstor";s:3:"fmf";s:24:"video/x-atomic3d-feature";s:3:"fpx";s:17:"image/vnd.net-fpx";s:3:"frl";s:22:"application/freeloader";s:4:"funk";s:10:"audio/make";s:2:"my";s:10:"audio/make";s:5:"pfunk";s:18:"audio/make.my.funk";s:2:"g3";s:11:"image/g3fax";s:3:"gif";s:9:"image/gif";s:2:"gl";s:10:"video/x-gl";s:3:"gsd";s:11:"audio/x-gsm";s:3:"gsm";s:11:"audio/x-gsm";s:3:"gsp";s:17:"application/x-gsp";s:3:"gss";s:17:"application/x-gss";s:4:"gtar";s:18:"application/x-gtar";s:2:"gz";s:18:"application/x-gzip";s:3:"tgz";s:18:"application/gnutar";s:1:"z";s:22:"application/x-compress";s:3:"zip";s:15:"multipart/x-zip";s:4:"gzip";s:16:"multipart/x-gzip";s:3:"hdf";s:17:"application/x-hdf";s:4:"help";s:22:"application/x-helpfile";s:3:"hlp";s:21:"application/x-winhelp";s:3:"hgl";s:23:"application/vnd.hp-hpgl";s:3:"hpg";s:23:"application/vnd.hp-hpgl";s:4:"hpgl";s:23:"application/vnd.hp-hpgl";s:3:"hlb";s:13:"text/x-script";s:3:"hqx";s:26:"application/x-mac-binhex40";s:3:"hta";s:15:"application/hta";s:3:"htc";s:16:"text/x-component";s:3:"htt";s:16:"text/webviewhtml";s:3:"ice";s:23:"x-conference/x-cooltalk";s:3:"ico";s:12:"image/x-icon";s:3:"ief";s:9:"image/ief";s:4:"iefs";s:9:"image/ief";s:4:"iges";s:10:"model/iges";s:3:"igs";s:10:"model/iges";s:3:"ima";s:17:"application/x-ima";s:4:"imap";s:24:"application/x-httpd-imap";s:3:"inf";s:15:"application/inf";s:3:"ins";s:30:"application/x-internett-signup";s:2:"ip";s:17:"application/x-ip2";s:3:"isu";s:15:"video/x-isvideo";s:2:"it";s:8:"audio/it";s:2:"iv";s:22:"application/x-inventor";s:3:"ivr";s:14:"i-world/i-vrml";s:3:"ivy";s:24:"application/x-livescreen";s:3:"jam";s:11:"audio/x-jam";s:3:"jcm";s:27:"application/x-java-commerce";s:4:"jfif";s:11:"image/pjpeg";s:9:"jfif-tbnl";s:10:"image/jpeg";s:3:"jpe";s:11:"image/pjpeg";s:4:"jpeg";s:11:"image/pjpeg";s:3:"jpg";s:11:"image/pjpeg";s:3:"jps";s:11:"image/x-jps";s:2:"js";s:24:"application/x-javascript";s:3:"jut";s:15:"image/jutvision";s:3:"kar";s:15:"music/x-karaoke";s:3:"mid";s:14:"x-music/x-midi";s:4:"midi";s:14:"x-music/x-midi";s:3:"ksh";s:17:"text/x-script.ksh";s:2:"la";s:16:"audio/x-nspaudio";s:3:"lma";s:16:"audio/x-nspaudio";s:3:"lam";s:17:"audio/x-liveaudio";s:5:"latex";s:19:"application/x-latex";s:3:"ltx";s:19:"application/x-latex";s:3:"lsp";s:18:"text/x-script.lisp";s:3:"lsx";s:13:"text/x-la-asf";s:3:"m1v";s:10:"video/mpeg";s:3:"m2v";s:10:"video/mpeg";s:3:"mp2";s:14:"video/x-mpeq2a";s:3:"mp3";s:14:"audio/x-mpeg-3";s:3:"mpa";s:10:"audio/mpeg";s:3:"mpe";s:10:"video/mpeg";s:4:"mpeg";s:10:"video/mpeg";s:3:"mpg";s:10:"audio/mpeg";s:3:"m2a";s:10:"audio/mpeg";s:4:"mpga";s:10:"audio/mpeg";s:3:"m3u";s:15:"audio/x-mpequrl";s:3:"man";s:23:"application/x-troff-man";s:3:"map";s:21:"application/x-navimap";s:3:"mbd";s:19:"application/mbedlet";s:3:"mc$";s:35:"application/x-magic-cap-package-1.0";s:3:"mcd";s:21:"application/x-mathcad";s:3:"mcf";s:8:"text/mcf";s:3:"mcp";s:17:"application/netmc";s:2:"me";s:22:"application/x-troff-me";s:3:"mht";s:14:"message/rfc822";s:5:"mhtml";s:14:"message/rfc822";s:4:"mime";s:8:"www/mime";s:3:"mif";s:17:"application/x-mif";s:3:"mjf";s:42:"audio/x-vnd.audioexplosion.mjuicemediafile";s:4:"mjpg";s:19:"video/x-motion-jpeg";s:2:"mm";s:18:"application/x-meme";s:3:"mme";s:18:"application/base64";s:3:"mod";s:11:"audio/x-mod";s:4:"moov";s:15:"video/quicktime";s:3:"mov";s:15:"video/quicktime";s:2:"qt";s:15:"video/quicktime";s:5:"movie";s:17:"video/x-sgi-movie";s:2:"mv";s:17:"video/x-sgi-movie";s:3:"mpc";s:21:"application/x-project";s:3:"mpt";s:21:"application/x-project";s:3:"mpv";s:21:"application/x-project";s:3:"mpx";s:21:"application/x-project";s:3:"mpp";s:26:"application/vnd.ms-project";s:3:"mrc";s:16:"application/marc";s:2:"ms";s:22:"application/x-troff-ms";s:3:"mzz";s:36:"application/x-vnd.audioexplosion.mzz";s:3:"nap";s:12:"image/naplps";s:6:"naplps";s:12:"image/naplps";s:3:"ncm";s:43:"application/vnd.nokia.configuration-message";s:3:"nif";s:12:"image/x-niff";s:4:"niff";s:12:"image/x-niff";s:3:"nix";s:26:"application/x-mix-transfer";s:3:"nsc";s:24:"application/x-conference";s:3:"nvd";s:21:"application/x-navidoc";s:3:"oda";s:15:"application/oda";s:3:"omc";s:17:"application/x-omc";s:4:"omcd";s:26:"application/x-omcdatamaker";s:4:"omcr";s:26:"application/x-omcregerator";s:1:"p";s:13:"text/x-pascal";s:3:"p10";s:20:"application/x-pkcs10";s:3:"p12";s:20:"application/x-pkcs12";s:3:"p7a";s:29:"application/x-pkcs7-signature";s:3:"p7c";s:24:"application/x-pkcs7-mime";s:3:"p7m";s:24:"application/x-pkcs7-mime";s:3:"p7r";s:31:"application/x-pkcs7-certreqresp";s:3:"p7s";s:27:"application/pkcs7-signature";s:4:"part";s:19:"application/pro_eng";s:3:"prt";s:19:"application/pro_eng";s:3:"pas";s:11:"text/pascal";s:3:"pbm";s:23:"image/x-portable-bitmap";s:3:"pcl";s:17:"application/x-pcl";s:3:"pct";s:12:"image/x-pict";s:3:"pcx";s:11:"image/x-pcx";s:3:"pdb";s:14:"chemical/x-pdb";s:3:"xyz";s:14:"chemical/x-pdb";s:3:"pdf";s:15:"application/pdf";s:3:"pgm";s:24:"image/x-portable-greymap";s:3:"pic";s:10:"image/pict";s:4:"pict";s:10:"image/pict";s:3:"pkg";s:35:"application/x-newton-compatible-pkg";s:3:"pko";s:26:"application/vnd.ms-pki.pko";s:3:"plx";s:25:"application/x-pixclscript";s:2:"pm";s:25:"text/x-script.perl-module";s:3:"xpm";s:9:"image/xpm";s:3:"pm4";s:23:"application/x-pagemaker";s:3:"pm5";s:23:"application/x-pagemaker";s:3:"png";s:9:"image/png";s:5:"x-png";s:9:"image/png";s:3:"pnm";s:23:"image/x-portable-anymap";s:3:"pot";s:29:"application/vnd.ms-powerpoint";s:3:"pps";s:29:"application/vnd.ms-powerpoint";s:3:"ppt";s:26:"application/x-mspowerpoint";s:3:"ppz";s:24:"application/mspowerpoint";s:3:"ppa";s:29:"application/vnd.ms-powerpoint";s:3:"pwz";s:29:"application/vnd.ms-powerpoint";s:3:"pov";s:11:"model/x-pov";s:3:"ppm";s:23:"image/x-portable-pixmap";s:3:"pre";s:23:"application/x-freelance";s:3:"pvu";s:12:"paleovu/x-pv";s:2:"py";s:20:"text/x-script.phyton";s:3:"pyc";s:29:"applicaiton/x-bytecode.python";s:3:"qcp";s:15:"audio/vnd.qcelp";s:3:"qif";s:17:"image/x-quicktime";s:3:"qti";s:17:"image/x-quicktime";s:4:"qtif";s:17:"image/x-quicktime";s:3:"qtc";s:11:"video/x-qtc";s:2:"ra";s:17:"audio/x-realaudio";s:3:"ram";s:20:"audio/x-pn-realaudio";s:2:"rm";s:28:"application/vnd.rn-realmedia";s:3:"rmm";s:20:"audio/x-pn-realaudio";s:3:"rmp";s:27:"audio/x-pn-realaudio-plugin";s:3:"rpm";s:27:"audio/x-pn-realaudio-plugin";s:3:"ras";s:18:"image/x-cmu-raster";s:4:"rast";s:16:"image/cmu-raster";s:4:"rexx";s:18:"text/x-script.rexx";s:2:"rf";s:22:"image/vnd.rn-realflash";s:3:"rgb";s:11:"image/x-rgb";s:3:"rmi";s:9:"audio/mid";s:3:"rng";s:34:"application/vnd.nokia.ringing-tone";s:3:"rnx";s:29:"application/vnd.rn-realplayer";s:4:"roff";s:19:"application/x-troff";s:1:"t";s:19:"application/x-troff";s:2:"tr";s:19:"application/x-troff";s:2:"rp";s:20:"image/vnd.rn-realpix";s:2:"rt";s:20:"text/vnd.rn-realtext";s:3:"rtf";s:17:"application/x-rtf";s:3:"rtx";s:15:"application/rtf";s:2:"rv";s:22:"video/vnd.rn-realvideo";s:3:"s3m";s:9:"audio/s3m";s:3:"sbk";s:19:"application/x-tbook";s:3:"tbk";s:20:"application/toolbook";s:3:"scm";s:11:"video/x-scm";s:3:"sdp";s:17:"application/x-sdp";s:3:"sdr";s:19:"application/sounder";s:3:"sea";s:17:"application/x-sea";s:3:"set";s:15:"application/set";s:3:"sgm";s:11:"text/x-sgml";s:4:"sgml";s:11:"text/x-sgml";s:3:"ssi";s:25:"text/x-server-parsed-html";s:3:"sid";s:12:"audio/x-psid";s:3:"sit";s:21:"application/x-stuffit";s:3:"skd";s:18:"application/x-koan";s:3:"skm";s:18:"application/x-koan";s:3:"skp";s:18:"application/x-koan";s:3:"skt";s:18:"application/x-koan";s:2:"sl";s:21:"application/x-seelogo";s:3:"smi";s:16:"application/smil";s:4:"smil";s:16:"application/smil";s:3:"sol";s:18:"application/solids";s:3:"spc";s:13:"text/x-speech";s:4:"talk";s:13:"text/x-speech";s:3:"spl";s:24:"application/futuresplash";s:3:"spr";s:20:"application/x-sprite";s:6:"sprite";s:20:"application/x-sprite";s:3:"src";s:25:"application/x-wais-source";s:4:"wsrc";s:25:"application/x-wais-source";s:3:"ssm";s:26:"application/streamingmedia";s:3:"sst";s:32:"application/vnd.ms-pki.certstore";s:4:"step";s:16:"application/step";s:3:"stp";s:16:"application/step";s:3:"stl";s:23:"application/x-navistyle";s:7:"sv4cpio";s:21:"application/x-sv4cpio";s:6:"sv4crc";s:20:"application/x-sv4crc";s:3:"svr";s:13:"x-world/x-svr";s:3:"wrl";s:14:"x-world/x-vrml";s:3:"swf";s:29:"application/x-shockwave-flash";s:3:"tar";s:17:"application/x-tar";s:3:"tcl";s:17:"text/x-script.tcl";s:4:"tcsh";s:18:"text/x-script.tcsh";s:3:"tex";s:17:"application/x-tex";s:4:"texi";s:21:"application/x-texinfo";s:7:"texinfo";s:21:"application/x-texinfo";s:3:"tif";s:12:"image/x-tiff";s:4:"tiff";s:12:"image/x-tiff";s:3:"tsi";s:15:"audio/tsp-audio";s:3:"tsp";s:14:"audio/tsplayer";s:3:"tsv";s:25:"text/tab-separated-values";s:3:"uil";s:10:"text/x-uil";s:3:"uni";s:13:"text/uri-list";s:4:"unis";s:13:"text/uri-list";s:3:"uri";s:13:"text/uri-list";s:4:"uris";s:13:"text/uri-list";s:3:"unv";s:18:"application/i-deas";s:5:"ustar";s:17:"multipart/x-ustar";s:3:"uue";s:15:"text/x-uuencode";s:3:"vcd";s:20:"application/x-cdlink";s:3:"vcs";s:16:"text/x-vcalendar";s:3:"vda";s:15:"application/vda";s:3:"vdo";s:9:"video/vdo";s:3:"vew";s:21:"application/groupwise";s:3:"viv";s:14:"video/vnd.vivo";s:4:"vivo";s:14:"video/vnd.vivo";s:3:"vmd";s:31:"application/vocaltec-media-desc";s:3:"vmf";s:31:"application/vocaltec-media-file";s:3:"voc";s:11:"audio/x-voc";s:3:"vos";s:12:"video/vosaic";s:3:"vox";s:13:"audio/voxware";s:3:"vqe";s:21:"audio/x-twinvq-plugin";s:3:"vql";s:21:"audio/x-twinvq-plugin";s:3:"vqf";s:14:"audio/x-twinvq";s:4:"vrml";s:14:"x-world/x-vrml";s:3:"wrz";s:14:"x-world/x-vrml";s:3:"vrt";s:13:"x-world/x-vrt";s:3:"vsd";s:19:"application/x-visio";s:3:"vst";s:19:"application/x-visio";s:3:"vsw";s:19:"application/x-visio";s:3:"w60";s:26:"application/wordperfect6.0";s:3:"wp5";s:23:"application/wordperfect";s:3:"w61";s:26:"application/wordperfect6.1";s:3:"wav";s:11:"audio/x-wav";s:3:"wb1";s:18:"application/x-qpro";s:4:"wbmp";s:18:"image/vnd.wap.wbmp";s:3:"web";s:20:"application/vnd.xara";s:3:"wk1";s:17:"application/x-123";s:3:"wmf";s:16:"windows/metafile";s:3:"wml";s:16:"text/vnd.wap.wml";s:4:"wmlc";s:24:"application/vnd.wap.wmlc";s:4:"wmls";s:22:"text/vnd.wap.wmlscript";s:5:"wmlsc";s:30:"application/vnd.wap.wmlscriptc";s:2:"wp";s:23:"application/wordperfect";s:3:"wp6";s:23:"application/wordperfect";s:3:"wpd";s:19:"application/x-wpwin";s:3:"wq1";s:19:"application/x-lotus";s:3:"wri";s:17:"application/x-wri";s:3:"wsc";s:13:"text/scriplet";s:3:"wtk";s:21:"application/x-wintalk";s:3:"xbm";s:9:"image/xbm";s:3:"xdr";s:19:"video/x-amt-demorun";s:3:"xgz";s:11:"xgl/drawing";s:3:"xif";s:14:"image/vnd.xiff";s:2:"xl";s:17:"application/excel";s:3:"xla";s:21:"application/x-msexcel";s:3:"xlb";s:24:"application/vnd.ms-excel";s:3:"xlc";s:24:"application/vnd.ms-excel";s:3:"xld";s:19:"application/x-excel";s:3:"xlk";s:19:"application/x-excel";s:3:"xll";s:24:"application/vnd.ms-excel";s:3:"xlm";s:24:"application/vnd.ms-excel";s:3:"xls";s:24:"application/vnd.ms-excel";s:3:"xlt";s:19:"application/x-excel";s:3:"xlv";s:19:"application/x-excel";s:3:"xlw";s:24:"application/vnd.ms-excel";s:2:"xm";s:8:"audio/xm";s:3:"xml";s:8:"text/xml";s:3:"xmz";s:9:"xgl/movie";s:4:"xpix";s:25:"application/x-vnd.ls-xpix";s:3:"xsr";s:19:"video/x-amt-showrun";s:3:"xwd";s:19:"image/x-xwindowdump";s:3:"zsh";s:17:"text/x-script.zsh";}');

	return $types[$file_ext];
}
