<?php
/**
 * View类,用来保存控制跟页面的数据传递,并显示页面和布局
 *
 */
class View
{
	/**
	 * 用来保存页面数据
	 *
	 * @var array
	 */
	protected $_data=array();
	
	/**
	 * 采用的布局,PHP文件的绝对路径
	 *
	 * @var string
	 */
	protected $_layout=null;
	
	/**
	 * 视图文件的绝对路径
	 *
	 * @var string
	 */
	protected $_view_file;
	
	/**
	 * 魔术方法取值
	 *
	 * @param string $key
	 * @return mixed
	 */
	public function __get($key)
	{
		return $this->_data[$key];
	}
	
	/**
	 * 魔术方法设置值
	 *
	 * @param string $key
	 * @param mixed $value
	 */
	public function __set($key,$value)
	{
		$this->_data[$key]=$value;
	}
	
	
	/**
	 * 设置布局文件,为绝对路径
	 *
	 * @param string $layout_file 为绝对路径
	 */
	public function setLayout($layout_file)
	{
		$this->_layout=$layout_file;
	}
	
	
	/**
	 * 显示页面,为绝对路径,如果有布局的话,则先调用布局,然后再局中再调用getDisplayFile()
	 *
	 * @param string $view_file ,为绝对路径
	 */
	public function display($view_file="")
	{
		$this->_view_file=$view_file;
		extract($this->_data);
		if(empty($this->_layout))
		{
			if(IS_DEBUG)
			{
				if(!file_exists($view_file))
				{
					throw new Exception('视图文件'.$view_file.'不存在');
					
					return ;
				}
			}
			include($view_file);
		}
		else 
		{
			if(IS_DEBUG)
			{
				if(!file_exists($this->_layout))
				{
					throw new Exception('布局文件'.$this->_layout.'不存在');
					return ;
				}
			}
			include($this->_layout);
		}
	}
	
	/**
	 * 在布局中调用action对应的页面
	 *
	 * @return string   页面的绝对路径
	 */
	public function getDisplayFile()
	{
		$view_file=$this->_view_file;
		if(IS_DEBUG)
		{
			if(!file_exists($view_file))
			{
				throw new Exception('视图文件'.$view_file.'不存在');
				return ;
			}
		}
		return $this->_view_file;
	}
	
}