<?php
include_once('library/rest_common.php');
include_once('library/RestClient.php');
/**
 * 所有自动生成的Rest类的基类
 *
 */
class RestBase 
{
	protected  $_contents;
	
	/**
	 * 把xml映射为该对象及其子对象的属性的值
	 *
	 * @param string $xml_string
	 */
	public function fromXMLString($xml_string)
	{
		xmlToObject($xml_string,$this);
	}
	
	/**
	 * 把数组映射为该对象及其子对象的属性的值
	 *
	 * @param array $array
	 */
	public function fromArray($array)
	{
		arrayToObject($array,$this);
	}
	
	/**
	 * 把json映射为该对象及其子对象的属性的值
	 *
	 * @param string $json_string
	 */
	public function fromJson($json_string)
	{
		jsonToObject(json_decode($json_string),$this);
	}
	
	/**
	 * 从url取值,并赋值给该对象及其子对象
	 *
	 * @param string $url
	 * @param array  $data
	 * @return boolean
	 */
	public function loadDataFromURL($url,$data=array(),$is_tvm_rest=true)
	{
		if($is_tvm_rest)
		{
			$client=new RestClient($url);
			$data=$client->post(new RestParam($data));
			
			if($client->isSuccess())
			{
				arrayToObject($data,$this);
				return true;
			}
		}
		else 
		{
			$contents=file_get_contents($url);
			$this->_contents=$contents;
			if($contents{0}=='{')
			{
				jsonToObject(json_decode($contents),$this);
			}
			else 
			{
				xmlToObject($contents,$this);
			}
			return true;
		}
		return false;
	}
	
	/**
	 * 把该对象及其子对象的值变为xml字符串
	 *
	 * @return string
	 */
	public function toXMLString()
	{
		return objectToXML($this);
	}
	
	/**
	 * 把该对象及其子对象的值变为数组
	 *
	 * @return array
	 */
	public function toArray()
	{
		return objectToArray($this);
	}
	
	
}