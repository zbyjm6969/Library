<?php
/**
 * 用来控制memcache缓存
 *
 */
class ModelMemcache
{
	/**
	 * ModelMemcache的单例实例
	 *
	 * @var ModelMemcache
	 */
	public static $instance=null;
	
	/**
	 * Memcache 连接
	 *
	 * @var Memcache
	 */
	public $mem_con=null;
	
	/**
	 * 取单实例对象
	 *
	 * @return  ModelMemcache
	 */
	public static  function getInstance()
	{
		if(self::$instance==null)
		{
			self::$instance=new ModelMemcache();
		}
		return self::$instance;
	}
	
	/**
	 * 单例的构造函数
	 *
	 */
	public function __construct()
	{
		if(self::$instance!=null)
		{
			throw new Exception("ModelMemcache instance is build");
			return ;
		}
		
	}
	
	public function __destruct()
	{
		
	}
	/**
	 * 单进程获取,从memcache中获取,如果不存则锁住,然后从数据库中获取,设置到memcache缓存,
	 *
	 * @param CModel $model
	 * @param string $key
	 * @param string $sql
	 * @return array
	 */
	protected  function singleGet($model,$key,$sql)
	{
		$arr_output=$this->mem_con->get($key);
		
		if($arr_output!==false)
		{
			return unserialize($arr_output);
		}
		for($i=0;$this->is_lock('lock_'.$key);$i++)
		{
			sleep(1);
			$arr_output=$this->mem_con->get($key);
			if($arr_output!==false)
			{
				return unserialize($arr_output);
			}
			if($i>=5)
			{
				throw new Exception("连接数据库超时");
			}
		}
		$this->lock('lock_'.$key);
		
		$arr_output=$this->getByDb($model,$sql);
		$this->mem_con->set($key,serialize($arr_output));
		$this->unLock('lock_'.$key);
		return $arr_output;
	}
	
	/**
	 * 直接从数据库获取
	 *
	 * @param CModel $model
	 * @param string $sql
	 * @return array
	 */
	protected  function getByDb($model,$sql)
	{
		
		$stmt=$model->_cur_db_conn->query($sql);
		$arr_output=$stmt->fetchAll(PDO::FETCH_ASSOC);
		
		return $arr_output;
	}
	
	/**
	 * 所有的查询都通过此方法来获取
	 *
	 * @param CModel $model
	 * @param string $sql
	 * @param array $cache_type
	 * @param array $primary_key
	 * @return array
	 */
	public function get($model,$sql,$cache_type,$primary_key=array())
	{
		if(!MODEL_CACHE)
		{
			return $this->getByDb($model,$sql);
		}
		
		$this->mem_con=$model->_conn_manager->getMemcache($model->_database_name,$model->_table_name);
		$m_cache_type=$model->_cache_type;
		if(!empty($primary_key)&&!$m_cache_type['single'])//根据主键取,但又不缓存单条记录
		{
			return $this->getByDb($model,$sql);
		}
		else if(!empty($primary_key)) 
		{
			$key=$this->generateKey($model,array(),'single',$sql);
			return $this->singleGet($model,$key,$sql);
		}
		
		if(!empty($cache_type))
		{
			$key=$this->generateKey($model,$cache_type,'multiple',$sql);
			return $this->singleGet($model,$key,$sql);
		}
		
		if($m_cache_type['complex'])
		{
			$key=$this->generateKey($model,$cache_type,'complex',$sql);
			return $this->singleGet($model,$key,$sql);
		}
		return $this->getByDb($model,$sql);
	}
	
	/**
	 * 某一个查询是否被锁住
	 *
	 * @param string $key
	 * @return  bool
	 */
	public function is_lock($key)
	{
		return $this->mem_con->get($key) ? true:false;
	}
	/**
	 * 锁住一个查询
	 *
	 * @param string $key
	 */
	public function lock($key)
	{
		$this->mem_con->set($key,1);
	}
	
	/**
	 * 查询完成进行解锁
	 *
	 * @param string $key
	 */
	public function unLock($key)
	{
		$this->mem_con->set($key,0);
	}
	/**
	 * 取某一个命名空间的当前版本
	 *
	 * @param CModel $model
	 * @param array $cache_type
	 * @param string $type  'single','complex','multiple'
	 * @return  int
	 */
	public function getVersion($model,$cache_type,$type)
	{
		$key=$model->_database_name.$model->_farm_id."_".$model->_table_name;
		if(!($type=='single'&&MODEL_CACHE_MYSQL))
		{
			$table_version=$this->getTableVersion($model);
			$key.="_".$table_version;
		}
		if(!empty($type))
		{
			$key.="_".$type;
		}
		$key.=$this->getCacheTypeKey($model,$cache_type);
		$key='version_'.$key;
		$version=$this->mem_con->get($key);
		if($version!==false)
		{
			return $version;
		}
		for($i=0;$this->is_lock('lock_'.$key);$i++)
		{
			sleep(1);
			$version=$this->mem_con->get($key);
			if($version!==false)
			{
				return $version;
			}
			if($i>=5)
			{
				throw new Exception("连接数据库超时");
			}
		}
		$this->lock('lock_'.$key);
		$this->mem_con->set($key,1);
		$this->unLock('lock_'.$key);
		return 1;
	}
	
	/**
	 * 取表的命名空间的版本
	 *
	 * @param CModel $model
	 * @return int
	 */
	public function getTableVersion($model)
	{
		$key=$model->_database_name.$model->_farm_id."_".$model->_table_name;
		
		$key='version_'.$key;
		$version=$this->mem_con->get($key);
		if($version!==false)
		{
			return $version;
		}
		for($i=0;$this->is_lock('lock_'.$key);$i++)
		{
			sleep(1);
			$version=$this->mem_con->get($key);
			if($version!==false)
			{
				return $version;
			}
			if($i>=5)
			{
				throw new Exception("连接数据库超时");
			}
		}
		$this->lock('lock_'.$key);
		$this->mem_con->set($key,1);
		$this->unLock('lock_'.$key);
		return 1;
	}
	
	/**
	 * 生成memcache的key
	 *
	 * @param CModel $model
	 * @param array $cache_type
	 * @param string $type  'single','complex','multiple'
	 * @param string $sql
	 * @return  string
	 */
	public function generateKey($model,$cache_type,$type,$sql="",$include_version=true)
	{
		$key=$model->_database_name.$model->_farm_id."_".$model->_table_name;
		if(!($type=='single'&&MODEL_CACHE_MYSQL))
		{
			$key.="_".$this->getTableVersion($model);
		}
		if(!empty($type))
		{
			$key.="_".$type;
		}
		$key.=$this->getCacheTypeKey($model,$cache_type);
		if($include_version&&$type!='single')
		{
			$version=$this->getVersion($model,$cache_type,$type);
			$key.="_".$version;
		}
		if(!empty($sql))
		{
			$key.="_".md5($sql);
		}
		return $key;
	}
	
	/**
	 * 获取多级缓存数组的转化成key的一部分的形式
	 *
	 * @param CModel $model
	 * @param array $cache_type
	 * @return string
	 */
	public function getCacheTypeKey($model,$cache_type)
	{
		$key="";
		if(!empty($cache_type))
		{
			$first_cache=key($cache_type);
			
			if(is_array($cache_type[$first_cache]))
			{
				$first_cache_value="";
				$second_cache="";
				$second_cache_value="";
				foreach ($cache_type[$first_cache] as $key1=>$value)
				{
					if(is_int($key1))
					{
						$first_cache_value=$value;
					}
					else 
					{
						$second_cache=$key1;
						$second_cache_value=$value;
					}
				}
				$key.="_".$first_cache_value;
				/*$key_version=$model->_database_name.$model->_farm_id."_".$model->_table_name;				
				$table_version=$this->getTableVersion($model);
				$key_version.="_".$table_version;
				$key_version.="_multiple";
				$key_version.=$key;
				$key_version='version_'.$key_version;
				$version=$this->mem_con->get($key_version);
				if($version!==false)
				{
					$key.="_".$version;
				}
				else 
				{
					for($i=0;$this->is_lock('lock_'.$key_version);$i++)
					{
						sleep(1);
						$version=$this->mem_con->get($key_version);
						if($version!==false)
						{
							$key.="_".$version;
							break;
						}
						if($i>=5)
						{
							throw new Exception("连接数据库超时");
						}
					}
					$this->lock('lock_'.$key_version);
					$this->mem_con->set($key_version,1);
					$this->unLock('lock_'.$key_version);
					$key.="_1";
				}*/
				$key.="_".$second_cache_value;
			}
			else 
			{
				$key.="_".$cache_type[$first_cache];
			}
		}
		return $key;
	}
	/**
	 * 普通删除,删除所有的杂项缓存,如果是通过多级删除,则删除对应的多级缓存,如果没有的话,则删除所有的多级缓存
	 *
	 * @param CModel $model
	 * @param array $cache_type
	 */
	public function clearCacheByNormal($model,$cache_type)
	{
		if(!MODEL_CACHE)
		{
			return ;
		}
		
		$this->mem_con=$model->_conn_manager->getMemcache($model->_database_name,$model->_table_name);
		$key=$model->_database_name.$model->_farm_id."_".$model->_table_name;
		if(!empty($cache_type))//清除相对应的多级缓存,及杂项缓存
		{
			
			$key.="_".$this->getTableVersion($model);
			if($model->_cache_type['complex'])
			{
				$this->incrementVersion('version_'.$key."_complex");
			}
			if(!MODEL_CACHE_MYSQL&&$model->_cache_type['single'])//如果没有mysql反向更新memcache则清除单条记录
			{
				$this->incrementVersion('version_'.$key."_single");
			}
			$this->clearMultipleCache($model,$cache_type);
			
		}
		else//提升表的命名空间版本 
		{
			$this->incrementVersion('version_'.$key);
		}
	}
	/**
	 * 通过主键来删除,删除所有的杂项缓存,删除对应的单条记录缓存,删除对应的多级缓存
	 *
	 * @param  $primary_key
	 * @param  $model
	 */
	public function clearCacheByPrimary($primary_key,$model,$cahe_type,$sql,$is_delete=false)
	{
		if(!MODEL_CACHE)
		{
			return ;
		}
		
		$this->mem_con=$model->_conn_manager->getMemcache($model->_database_name,$model->_table_name);
		$m_cache_type=$model->_cache_type;
		if($m_cache_type['single'])
		{
			$key=$this->generateKey($model,array(),'single',$sql);
			
			if($is_delete&&$m_cache_type['single'])
			{
				$this->mem_con->delete($key);
			}
			if(!$is_delete&&!MODEL_CACHE_MYSQL&&$m_cache_type['single'])
			{
				$this->mem_con->delete($key);
			}
		}
		
		$this->clearCacheByInsert($model,$cahe_type);
	}
	
	/**
	 * 插入时删除对应的缓存,有杂项缓存,如果有多级缓存,则删除对应的多级缓存
	 *
	 * @param CModel $model
	 * @param array $cache_type
	 */
	public function clearCacheByInsert($model,$cache_type)
	{
		if(!MODEL_CACHE)
		{
			return ;
		}
		
		$this->mem_con=$model->_conn_manager->getMemcache($model->_database_name,$model->_table_name);
		if($model->_cache_type['complex'])
		{
			$key=$this->generateKey($model,array(),'complex',"",false);
			
			$key="version_".$key;
			$this->incrementVersion($key);
		}
		if(!empty($cache_type))
		{
			$this->clearMultipleCache($model,$cache_type);
		}
	}
	/**
	 * 更新多级缓存的每一级
	 *
	 * @param CModel $model
	 * @param array $cache_type
	 */
	public function clearMultipleCache($model,$cache_type)
	{
		$this->mem_con=$model->_conn_manager->getMemcache($model->_database_name,$model->_table_name);
		$key=$model->_database_name.$model->_farm_id."_".$model->_table_name;
		$first_cache=key($cache_type);
		$first_cache_value="";
		
		if(is_array($cache_type[$first_cache]))
		{
			foreach ($cache_type[$first_cache] as $key1=>$value)
			{
				if(is_int($key1))
				{
					$first_cache_value=$value;
				}
				else 
				{
					$second_cache_value=$value;
				}
			}
			$this->incrementVersion('version_'.$key."_".$this->getTableVersion($model)."_multiple"."_".$first_cache_value."_".$second_cache_value);
		}
		else 
		{
			$first_cache_value=$cache_type[$first_cache];
		}
		$this->incrementVersion('version_'.$key."_".$this->getTableVersion($model)."_multiple"."_".$first_cache_value);
		
	}
	
	/**
	 * 更新时把一个多级缓存下的东西,更新到其它多级缓存下,只需要更新新的多级缓存
	 *
	 * @param unknown_type $where_cache_type
	 * @param unknown_type $new_cache_type
	 */
	public function clearUpdateCacheType($where_cache_type,$new_cache_type,$model)
	{
		$this->mem_con=$model->_conn_manager->getMemcache($model->_database_name,$model->_table_name);
		$key=$model->_database_name.$model->_farm_id."_".$model->_table_name;
		$first_cache=key($where_cache_type);
		$first_cache_value="";
		$second_cache="";
		
		if(is_array($where_cache_type[$first_cache]))
		{
			foreach ($where_cache_type[$first_cache] as $key1=>$value)
			{
				if(is_int($key1))
				{
					$first_cache_value=$value;
				}
				else 
				{
					$second_cache=$key1;
					$second_cache_value=$value;
				}
			}
		}
		else 
		{
			$first_cache_value=$where_cache_type[$first_cache];
		}
		$new_first_cache=key($new_cache_type);
		$new_first_cache_value="";
		$new_second_cache="";
		$new_second_cache_value=null;
		if(is_array($new_cache_type[$new_first_cache]))
		{
			foreach ($new_cache_type[$new_first_cache] as $key1=>$value)
			{
				if(is_int($key1))
				{
					$new_first_cache_value=$value;
				}
				else 
				{
					$new_second_cache=$key1;
					$new_second_cache_value=$value;
				}
				
			}
		}
		if($first_cache_value!=$new_first_cache_value)
		{
			$this->incrementVersion('version_'.$key."_".$this->getTableVersion($model)."_multiple"."_".$new_first_cache_value);
		}
		if($second_cache_value!=$new_second_cache_value&&!is_null($new_second_cache_value))
		{
			
			
				$key=$this->generateKey($model,$new_cache_type,'multiple',"",false);
				$this->incrementVersion('version_'.$key);
			
		}
		
	}
	
	/**
	 * 增加某一个命名空间的版本
	 *
	 * @param string $key
	 * @return bool
	 */
	protected function incrementVersion($key)
	{
		if($this->is_lock('lock_'.$key))
		{
			return true;
		}
		$this->lock('lock_'.$key);
		if($this->mem_con->get($key)!==false)
		{
			$this->mem_con->increment($key);
		}
		else 
		{
			$this->mem_con->set($key,1);
		}
		$this->unLock('lock_'.$key);
		return true;
	}
	/**
	 * 如果通过wherebuild里面有字符串无法解析对应的缓存,则清除整个表缓存
	 *
	 * @param CModel $model
	 */
	public function incrementTableVersion($model)
	{
		$key=$model->_database_name.$model->_farm_id."_".$model->_table_name;
		$key='version_'.$key;
		$this->incrementVersion($key);
	}
	
	
}