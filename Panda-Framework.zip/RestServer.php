<?php

define('RESTFUL_RESULT_TYPE_XML','xml');
define('RESTFUL_RESULT_TYPE_JSON','json');
include_once('library/rest_common.php');
if(!defined('RESTFUL_RESULT_TYPE'))
{
	throw new Exception('没有设置常量RESTFUL_RESULT_TYPE');
}

/**
 * 可以添加类或是函数,类只能添加一个,函数可以添加多个,函数和类不能同时添加.
 *
 */

class RestServer
{
	protected $_server_class=null;

	protected $_server_functions=array();

	protected $_restful_result_type=RESTFUL_RESULT_TYPE;
	
	protected $_tokens=array('cc2b61333389fe3832ec191c14c7f7aa',//tvmhome
							 'ae27615e36661cfbaf9af3f6cab2a080',//tvm weibo
							 '1a695c975adb8b2d87935b02c8492734',//cztv phpwind
							);
	/**
	 * 请求哪个函数或是方法
	 *
	 * @var string
	 */
	protected $_request_function=null;

	/**
	 * 要传递给所请求函数的参数,通过调用函数时直接传递的,
	 *
	 * @var array
	 */
	protected $_param;

	public function __construct()
	{

	}

	/**
	 * 设置监听类
	 *
	 * @param string $class_name  要添加监听的类名
	 */
	public function setClass($class_name)
	{
		if(!empty($this->_server_functions))
		{
			throw new Exception('已经添加了函数,不能添加类');
			return ;
		}
		$this->_server_class=$class_name;
	}

	/**
	 * 添加监听函数
	 *
	 * @param string $function_name  监听函数名
	 */
	public function addFunction($function_name)
	{
		if(!is_null($this->_server_class))
		{
			throw new Exception('已经添加了类,不能添加函数');
			return ;
		}
		$this->_server_functions[strtolower($function_name)]=$function_name;
	}

	/**
	 * 解析请求并对应相对应的方法,并返回相应的结果
	 *
	 */
	public function handle()
	{
		$result=array();

		if(strpos($_SERVER['HTTP_ACCEPT'],'text/json')!==false)
		{
		$this->_restful_result_type=RESTFUL_RESULT_TYPE_JSON;
		}
		else
		{
		$this->_restful_result_type=RESTFUL_RESULT_TYPE_XML;
		}
		try{
			$this->parseParamByRewrite();
			$this->initPutData();
			if(empty($_GET['token'])||!in_array($_GET['token'],$this->_tokens))
			{
				throw new RestException("token出错");
			}
			if(!empty($this->_server_class))
			{
				$this->_request_function=$this->_param[0];
				$rest_obj=new $this->_server_class($this->_request_function);
				
				array_shift($this->_param);
				if(is_callable(array(&$rest_obj,$this->_request_function)))
				{
					$result=call_user_func_array(array(&$rest_obj,$this->_request_function),$this->_param);
				}
				else
				{
					throw new RestException('监听类'.$this->_server_class."的方法".$this->_request_function."不可调用或是不存在");
				}
			}
			else if(!empty($this->_server_functions))
			{
				if(key_exists($this->_request_function,$this->_server_functions))
				{
					if(function_exists($this->_request_function))
					{
						$result=call_user_func_array($this->_request_function,$this->_param);
					}
					else
					{
						throw new RestException('没有设置监听函数'.$this->_request_function);
					}
				}
				else
				{
					throw new RestException('没有设置监听函数'.$this->_request_function);
				}
			}
			else
			{
				throw new RestException('没有设置监听函数或监听类');
			}
		}
		catch (RestException $e)
		{
			header('Content-Type: text/xml');
			echo $e;
			return ;
		}
		$contents="";
		if($this->_restful_result_type==RESTFUL_RESULT_TYPE_XML&&is_a($result,'RestResult'))
		{
			$contents=arrayToXML(array('packet'=>'success','message'=>'OK','data'=>$result->_data),$result->_text_columns);
		}
		else if($this->_restful_result_type==RESTFUL_RESULT_TYPE_XML)
		{
			header('Content-Type: text/xml');
			$contents=arrayToXML(array('packet'=>array('status'=>'success','message'=>'OK','data'=>$result)));
		}
		else if($this->_restful_result_type==RESTFUL_RESULT_TYPE_JSON)
		{
			if(is_a($result,'RestResult'))
			{
				$result=$result->_data;
			}
			$contents=json_encode(array('status'=>'success','message'=>'OK','data'=>$result));

		}
		header("Content-Length: ".strlen($contents));
		echo $contents;


	}

	/**
	 * 解析rewrite的url来匹配要调用哪个方法或函数,并直接给方法或函数传递的参数
	 *
	 */
	public function parseParamByRewrite()
	{
		if(!defined('BASE_URL'))
		{
			throw new RestException('没有定义常量BASE_URL');
			return ;
		}
		$request_uri=parse_url($_SERVER['REQUEST_URI']);
		$request_uri=$request_uri['path'];
		$request_uri=substr($request_uri,strlen(BASE_URL));
		$request_uri=explode("/",$request_uri);
		array_shift($request_uri);
		if(empty($request_uri[0]))
		{
			throw new RestException('没有设置要调用的方法或函数');
			return ;
		}
		$this->_request_function=strtolower($request_uri[0]);
		array_shift($request_uri);
		if(!empty($request_uri)&&empty($request_uri[count($request_uri)-1]))
		{
			array_pop($request_uri);
		}
		$this->_param=$request_uri;
	}

	/**
	 * 初始化PUT方法提交的数据
	 *
	 */
	private function initPutData()
	{

		if(strtolower($_SERVER['REQUEST_METHOD'])=='put')
		{
			$data=file_get_contents('php://input');
			$data=trim($data);
			
			if(get_magic_quotes_gpc())
			{
				//$data=stripslashes($data);
			}
			if($data{0}=='{')
			{
				$data=jsonToArray(json_decode($data));
			}
			else if($data{0}=='<')
			{


				$data=xmlToArray($data);
			}
			$_POST=$data;
		}
		else if(strtolower($_SERVER['REQUEST_METHOD'])=='post')
		{

			$data=$_POST;

			if(isset($data['xml']))
			{
				if(!empty($data['xml']))
				{
					$_POST=xmlToArray($data['xml']);
				}
				else
				{
					unset($_POST['xml']);
				}
			}
			else if(isset($data['json']))
			{

				if(!empty($data['json']))
				{
					$_POST=jsonToArray(json_decode($data['json']));
				}
				else
				{
					unset($_POST['json']);
				}
			}


		}
		$_REQUEST=@array_merge($_REQUEST,$_POST);
	}
}

/**
 * 业务逻辑层给restful代理时,如果是要返回xml给客户端,且需要有<![CDATA[content]]>'这样的数据时,则需要返回该类的对象
 *
 */
class RestResult
{
	/**
	 * 原本的数据
	 *
	 * @var mixed
	 */
	public $_data;

	/**
	 * 需要加<![CDATA[content]]>的字段名
	 *
	 * @var array
	 */
	public $_text_columns=array();

	/**
	 * 
	 *
	 * @param mixed $data
	 * @param array $text_columns
	 */
	public function __construct($data,$text_columns=array())
	{
		$this->_data=$data;
		$this->_text_columns=$text_columns;
	}
}



/**
 * RestFul的异常类,抛出的异常可以直接转化为xml
 *
 */
class RestException extends Exception
{
	public function __construct($msg,$code=0)
	{
		parent::__construct($msg,$code);
	}

	public function __toString()
	{
		$str='<?xml version="1.0" encoding="UTF-8"?>';
		$str.='<packet>';
		$str.='<status>failure</status>';
		$str.='<message>'.$this->message.'</message>';
		$str.='</packet>';
		return $str;
	}
}