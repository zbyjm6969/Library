<?php
/**
 * 构建where语句,
 * 如果条件是等于是要强制采用 id=>1这种方式,如果是普通的比如大于  'id>1';
 * 条件中强制不能有and or 条件连接
 * update,delete时强制不能有or,可以用多次查询来代替
 * update,delete 强制不能使用字符串形式,只能使用数组形式
 * 所有的根据主键来读,删,更新的操作只能通过设置model的属性来调用.
 * 如果有二级缓存的话,则要把二级缓存的值都传递进来,否则视为普通缓存,例如相片的第一级缓存是user_id,第二级缓存为album_id,如果要查找或更新删除具有album_id的,则也要把相对应的user_id传递过来
 * 如果有二级缓存的话,且是更新和删除时,则要把所对应的多级缓存的值给传递进来,否则报错
 *
 */
class WhereBuild
{
	/**
	 * 存储所有赋进来的值
	 *
	 * @var array
	 */
	public $data=array();
	
	/**
	 * array($limit,$offset)
	 *
	 * @var array
	 */
	public  $_limit=array();
	
	/**
	 * 用来存放order信息
	 *
	 * @var array
	 */
	public $_order=array();
	
	/**
	 * 存储group by 信息,包括having
	 *
	 * @var array
	 */
	public $_group_by=array();
	
	/**
	 * 添加sql的and where   不能包括关键字where
	 *
	 * @param string|array $data  可以为直接的where字符串,或是数组,如果是等于的话,比如id=1要写成 id=>1,如果是其它的则可以写成"uname like '%aa%'";
	 * @param bool $parent_and   与上次设置的值之间的关系是不是and
	 * @param bool $add_bracket  是否需要加括号
	 */
	function andWhere($data,$parent_and=true,$add_bracket=false)
	{
		$this->data[]=array('and',$data,$parent_and,$add_bracket);
	}
	/**
	 * 添加sql的or where   不能包括关键字where
	 *
	 * @param string|array $data  可以为直接的where字符串,或是数组,如果是等于的话,比如id=1要写成 id=>1,如果是其它的则可以写成"uname like '%aa%'";
	 * * @param bool $parent_and   与上次设置的值之间的关系是不是and
	 * @param bool $add_bracket  是否需要加括号
	 */
	function orWhere($data,$parent_and=true,$add_bracket=false)
	{
		$this->data[]=array('or',$data,$parent_and,$add_bracket);
	}
	
	/**
	 * 设置分页
	 *
	 * @param int $limit
	 * @param int $offset
	 */
	public function limit($limit,$offset=0)
	{
		$this->_limit=array($limit,$offset);
	}
	
	/**
	 * 把where里面的内容清空,相当于一个全新的where对象,不用去重新构建一个where对象
	 *
	 */
	public function clear()
	{
		$this->data=array();
		$this->_limit=array();
		$this->_order=array();
		$this->_group_by=array();
	}
	
	/**
	 * 设置排序
	 *
	 * @param string $column_name   字段名
	 * @param boolean $is_desc      desc:true,asc:false
	 */
	public function order($column_name,$is_desc=true)
	{
		$this->_order[$column_name]=$is_desc;	
	}
	
	/**
	 * 设置group by 信息
	 *
	 * @param string $column 跟sql里面的一样
	 * @param  $having
	 */
	public function groupBy($column,$having="")
	{
		$this->_group_by=array('column'=>$column,'having'=>$having);
	}
}