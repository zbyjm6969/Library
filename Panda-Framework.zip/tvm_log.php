<?php
/**
 * 当常量IS_DEBUG定义为以mysql开头时,把出错信息记录到数据库中.如果定义为mysql_show时则同时入库并在网页显示
 *
 */
include_once('model/TvmLogModel.php');
if(!defined('IS_DEBUG'))
{
	throw new Exception('没有定义常量IS_DEBUG');
}
if(strpos(IS_DEBUG,'mysql')!==false)
{
	if(strpos(IS_DEBUG,'show')!==false)
	{
		define('SHOW_DEBUG',true);
	}
	set_error_handler('tvmErrorHandler');
	set_exception_handler('tvmExceptionHandler');
	
}

function tvmErrorHandler($errno, $errstr, $errfile, $errline)
{
	$old_error_level=error_reporting(E_ALL&~E_NOTICE);
	$model=new TvmLogModel();
	$model->create_time=time();
	$model->error_type=$errno;
	$model->file=str_replace('\\','/',$errfile);
	$model->message=$errstr;
	$model->request_param=addslashes(serialize($_REQUEST));
	$model->request_url=$_SERVER['REQUEST_URI'];
	$model->detail_message=addslashes(serialize(debug_backtrace()));
	$model->insert();
	if(defined('SHOW_DEBUG'))
	{
		debug_print_backtrace();
	}
	error_reporting($old_error_level);
}

function tvmExceptionHandler(Exception $e)
{
	$model=new TvmLogModel();
	$model->create_time=time();
	$model->error_type=-1;
	$model->file=str_replace('\\','/',$e->getFile());
	$model->message=addslashes($e->getMessage());
	$model->request_param=addslashes(serialize($_REQUEST));
	$model->request_url=$_SERVER['REQUEST_URI'];
	$model->detail_message=addslashes(serialize($e));
	try {
		$model->insert();	
	}
	catch (Exception  $e1)
	{
		print_r($e1);
	}
	if(defined('SHOW_DEBUG'))
	{
		print_r($e);
	}
	
}