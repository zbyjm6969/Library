<?php
/**
 * 
 * 每个库对应每台服务器都要配置,对应的memcache有两种配置方式,一种是一个库只对应一个memcache,'memcache'=>array('localhost:11211','localhost:11212'),
 * 一种是里面的表都有独自对应的memcache服务器'tables'=>array('user_info'=>array('localhost:11211','localhost:11212'),'user_login'=>array('localhost:11213'))
 *$this->_databases=array("member1"=>array("localhost"//写操作的服务器,
 * 											"localhost"//读操作的服务器可以省略),
 * 						"member"=>array("localhost","localhost"));
 * 不能多个库对多个不同的memcache,比如表1对应了localhost:11211,localhost11212,表2对应了localhost:11211,localhost:11213
 * 以某个相同的memcache要有相同的memcache连接
 */


class DBConnections
{
	/**
	 * 所有的数据库信息
	 *
	 * @var array
	 */
	protected $_databases=null;

	/**
	 * 当前已经联接的数据库
	 *
	 * @var array
	 */
	protected $_links=array();
	
	/**
	 * 当前已经连接的memcache服务器
	 *
	 * @var array
	 */
	protected $_memcache_links=array();

	protected $_user="root";


	protected $_password="123456";

	public static $instance=null;

	/**
	 * 取单实例对象
	 *
	 * @return  DBConnections
	 */
	public static  function getInstance()
	{
		if(self::$instance==null)
		{
			self::$instance=new DBConnections();
		}
		return self::$instance;
	}

	public function __construct()
	{
		
		if(self::$instance!=null)
		{
			throw new Exception("DBConnections instance is build");
			return ;
		}
		if(!Registry::getInstance()->isRegisted('db'))
		{
			throw new Exception("请配置数据库连接");
		}
		$this->_user=DB_USERNAME;
		$this->_password=DB_PASSWORD;
		$this->_databases=Registry::getInstance()->get('db');
		
	}

	public function __destruct()
	{
		if(!empty($this->_links))//释放PDO
		{
			foreach ($this->_links as $key=>$value)
			{
				$this->_links[$key]=null;
			}

		}
		if(!empty($this->_memcache_links))//释放memcache
		{
			foreach ($this->_memcache_links as $i=>$value)
			{
				$this->_memcache_links[$i]->close();
			}
		}
		
	}

	/**
	 * 获取数据库连接的PDO
	 *
	 * @param string $db_name 有后缀分库的库名
	 * @param bool $is_write  是否是写操作,作读写分离
	 * @return PDO
	 */
	public function getPDO($db_name,$is_write=true)
	{
		
		$host=$this->_databases[$db_name];
		
		if(empty($host))
		{
			throw new Exception("{$db_name} 没有设置对应的服务器");
		}
		if(!$is_write&&key_exists(1,$host))
		{
			$host=$host[1];
		}
		else 
		{
			$host=$host[0];
		}
		if(isset($this->_links[$host]))
		{
			return $this->_links[$host];
		}
		else
		{
			
			try{
				$this->_links[$host]=new PDO("mysql:host={$host};dbname={$db_name}", $this->_user, $this->_password, array(PDO::ATTR_PERSISTENT => true));
				$this->_links[$host]->query("set names 'utf8'");
				return  $this->_links[$host];
			}
			catch (PDOException $e)
			{
				throw new Exception("link database {$db_name} error");
			}
		}

	}
	
	/**
	 * 获取表的相对应的memcache连接
	 *
	 * @param string $database_name
	 * @param string $table_name
	 * @return Memcache
	 */
	public function getMemcache($database_name,$table_name)
	{
		if(!empty($this->_databases[$database_name]['memcache']))
		{
			if(!empty($this->_memcache_links[$this->_databases[$database_name]['memcache'][0]]))
			{
				return $this->_memcache_links[$this->_databases[$database_name]['memcache'][0]];
			}
			else 
			{
				$memcache=new Memcache();
				$memcache_host=explode(':',$this->_databases[$database_name]['memcache'][0]);
				$memcache->connect($memcache_host[0],$memcache_host[1]);
				for($i=count($this->_databases[$database_name]['memcache'])-1;$i>=1;$i--)
				{
					$memcache_host=explode(':',$this->_databases[$database_name]['memcache'][$i]);
					$memcache->addServer($memcache_host[0],$memcache_host[1]);
				}
				$this->_memcache_links[$this->_databases[$database_name]['memcache'][0]]=$memcache;
				return $memcache;
			}
		}
		else if(!empty($this->_databases[$database_name]['tables']))
		{
			if(!empty($this->_databases[$database_name]['tables'][$table_name]))
			{
				if(!empty($this->_memcache_links[$this->_databases[$database_name]['tables'][$table_name][0]]))
				{
					return $this->_memcache_links[$this->_databases[$database_name]['tables'][$table_name][0]];
				}
				else 
				{
					$memcache=new Memcache();
					$memcache_host=explode(':',$this->_databases[$database_name]['tables'][$table_name][0]);
					$memcache->connect($memcache_host[0],$memcache_host[1]);
					for($i=count($this->_databases[$database_name]['tables'][$table_name])-1;$i>=1;$i--)
					{
						$memcache_host=explode(':',$this->_databases[$database_name]['tables'][$table_name][$i]);
						$memcache->addServer($memcache_host[0],$memcache_host[1]);
					}
					$this->_memcache_links[$this->_databases[$database_name]['tables'][$table_name][0]]=$memcache;
					return $memcache;
				}
			}
			else 
			{
				throw new Exception("数据库 {$database_name}.{$table_name}没有设置对应的memcache");
			}
		}
		else 
		{
			throw new Exception("数据库 {$database_name}.{$table_name}没有设置对应的memcache");
		}
	}

}
