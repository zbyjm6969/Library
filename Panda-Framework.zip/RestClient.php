<?php
if(!defined('RESTFUL_REQUEST_METHOD_GET'))
{
	define('RESTFUL_REQUEST_METHOD_GET','GET');
	define('RESTFUL_REQUEST_METHOD_POST','POST');
	define('RESTFUL_REQUEST_METHOD_PUT','PUT');
	define('RESTFUL_REQUEST_METHOD_DEFAULT',RESTFUL_REQUEST_METHOD_POST);
}


class RestClient
{
	/**
	 * 通parse_url解析过的数组
	 *
	 * @var array
	 */
	protected $_restful_uri;

	/**
	 * 调用结果是否为成功
	 *
	 * @var boolean
	 */
	protected $_is_success=false;

	/**
	 * 最后一次调用返回的字符串
	 *
	 * @var string
	 */
	public $last_contents;
	/**
	 * 构造函数
	 *
	 * @param string $restful_uri  要调用的url
	 * @param int    $port   调用的端口
	 * @param int   $time_out  调用的最长等待时间
	 */
	public function __construct($restful_uri,$port=80,$time_out=5)
	{
		if(empty($restful_uri))
		{
			throw new Exception('restful uri 不能为空');
		}

		$uri=parse_url($restful_uri);
		if(empty($uri['scheme'])||empty($uri['host']))
		{
			throw new Exception('resultful uri 错误');
		}
		if(empty($uri['path']))
		{
			$uri['path']='/';
		}
		else if($uri['path']{strlen($uri['path'])-1}!='/')
		{
			$uri['path'].='/';
		}
		
		if(empty($uri['port']))
		{
			$uri['port']=$port;
		}
		$uri['time_out']=$time_out;
		/*if(!empty($uri['query']))
		{
			$uri['path'].='?'.$uri['query'];
		}
		else if(empty($uri['path']))
		{
			$uri['path']="/";
		}*/
		$this->_restful_uri=$uri;


	}

	/**
	 * 魔术方法,把所有要调用的方法映射成url
	 *
	 * @param string $method
	 * @param array $args
	 * @return mixed
	 */
	public function __call($method,$args)
	{
		$method.="/".implode("/",$args);
		$this->_restful_uri['method']=$method;
		return $this->call(RESTFUL_REQUEST_METHOD_DEFAULT,'');
		
	}

	/**
	 * 
	 *
	 * @param string $request_type  常量RESTFUL_REQUEST_METHOD_GET  RESTFUL_REQUEST_METHOD_POST
	 * @param string $param
	 * @return mixed
	 */
	protected function call($request_type,$param)
	{
		if(strpos($this->_restful_uri['method'],"?"))
		{
			$this->_restful_uri['method'].="&token=cc2b61333389fe3832ec191c14c7f7aa";
		}
		else 
		{
			$this->_restful_uri['method'].="?token=cc2b61333389fe3832ec191c14c7f7aa";
		}
		$contents =getContentsBySockOpen($request_type,$param,$this->_restful_uri['host'],$this->_restful_uri['path'].$this->_restful_uri['method'], $this->_restful_uri['port'], $this->_restful_uri['time_out']);

		if (defined('DEBUG_REST') && DEBUG_REST) {
			$file = "/opt/cztv_data/cztv/trunk/rest.log";
	    	$s = @file_get_contents($file);
	    	$s .= var_export(array($request_type,$param,$this->_restful_uri['host'],$this->_restful_uri['path'].$this->_restful_uri['method'], $this->_restful_uri['port'], $this->_restful_uri['time_out'],$contents),true);
	    	file_put_contents($file,$s);
		}
		
		$this->last_contents=$contents;
		
		if($contents{0}=='{')
		{
			$contents=jsonToArray(json_decode($contents));
		}
		else
		{
			
			$contents=xmlToArray($contents);
		}
		if($contents['status']!='success')
		{
			$this->_is_success=false;
		}
		else
		{
			$this->_is_success=true;
		}
		$contents=$contents['data'];
		
		return $contents;

	}

	/**
	 * 上次调用的结果是否成功
	 *
	 * @return boolean
	 */
	public function isSuccess()
	{
		return $this->_is_success;
	}

	/**
	 * 用get提交数据
	 *
	 * @param string $method
	 * @param RestParam $param
	 * @return mixed
	 */
	public function get($method,RestParam $param=null)
	{
		$this->_restful_uri['method']=$method;
		if(!empty($param))
		{
			$param=$param->getData();
		}
		else
		{
			$param="";
		}
		return $this->call(RESTFUL_REQUEST_METHOD_GET,$param);
	}

	/**
	 * 用post提交数据
	 *
	 * @param string $method
	 * @param RestParam $param
	 * @return mixed
	 */
	public function post($method,RestParam $param=null,$data_type='json')
	{
		$this->_restful_uri['method']=$method;
		if(!empty($param))
		{
			$param=$param->getData($data_type,'put');
		}
		else
		{
			$param="";
		}
		return $this->call(RESTFUL_REQUEST_METHOD_PUT,$param);
	}
	
	/**
	 * 用PUT提交数据
	 *
	 * @param string $method
	 * @param RestParam $param
	 * @return mixed
	 */
	public function put($method,RestParam $param=null,$data_type='xml')
	{
		$this->_restful_uri['method']=$method;
		if(!empty($param))
		{
			$param=$param->getData($data_type,'put');
		}
		else
		{
			$param="";
		}
		return $this->call(RESTFUL_REQUEST_METHOD_PUT,$param);
	}
}

/**
 * 用来给RestClient传递参数的对象
 * 被设置的数据只能是数组
 *
 */
class RestParam
{
	protected $_data=array();

	public function __construct($data=array())
	{
		$this->_data=$data;
	}
	
	/**
	 * 把数组转换成所需要的数据类型,xml或是json
	 *
	 * @param unknown_type $data_type
	 * @param unknown_type $request_type
	 * @return unknown
	 */
	public function getData($data_type='json',$request_type='post')
	{
		$data_type=strtolower($data_type);
		$request_type=strtolower($request_type);
		if($data_type=='json')
		{
			if($request_type=='post'||$request_type=='get')
			{
				return 'json='.json_encode($this->_data);
			}
			else 
			{
				return json_encode($this->_data);
			}
		}
		else 
		{
			$xml='';
			if(!empty($this->_data))
			{
				$xml.=arrayToXML($this->_data);
			}
			$xml='<xml>'.$xml.'</xml>';
			if($request_type=='post'||$request_type=='get')
			{
				return $xml='xml='.$xml;
			}
			return $xml;
		}
		
	}
	public function __set($key,$value)
	{
		$this->_data[$key]=$value;
	}
}


/*$rest_client=new RestClient('http://demo9015.net/image/getlist/1');
$rest_client->test('amuse');
$contents=$rest_client->get(new RestParam(array('id'=>1,'username'=>'陈繁荣')));*/