<?php
/*~ CModel.php
.---------------------------------------------------------------------------.
|  Software: PHP database table orm model class                             |
|   Version: 1.0                                                            |
|    Author: fanrong.chen                           |
*/

/**
 * Class CModel PHP database table orm model class
 * 如果字段是数字或时间可以有函数或是value=value+1
 * 
 *
 */

class CModel
{
	/**
	 * 是否有自增长字段
	 *
	 * @var bool
	 */
	protected $_have_auto_increment=false;

	/**
	 * 表名
	 *
	 * @var string
	 */
	protected $_table_name;

	/**
	 * 数据库名
	 *
	 * @var string
	 */
	protected $_database_name;

	/**
	 * 数据库连接的管理
	 *
	 * @var DBConnections
	 */
	protected $_conn_manager=null;
	/**
	 * 分库数量
	 *
	 * @var int
	 */
	protected $_farm_num=10;

	/**
	 * 分库字段,array('type'=>array(1,2,3))     array('user_id'=>1)
	 *
	 * @var array
	 */
	protected $_farm_field=null;

	/**
	 * 分库ID
	 *
	 * @var int
	 */
	protected $_farm_id=null;

	/**
	 * 当前数据库连接
	 *
	 * @var PDO
	 */
	protected $_cur_db_conn=null;


	/**
	 * 键值方式保存所有的类的数据类型
	 *
	 * @var array
	 */
	protected $_column_types=array();

	/**
	 * 所有的主键名
	 *
	 * @var array
	 */
	protected $_primary_keys=array();

	/**
	 * 所有不能为空的字段,不包括自增长键和有默认值的键
	 *
	 * @var array
	 */
	protected $_not_nullable_columns=array();

	/**
	 * 所有的字符型的字段的长度信息,包括char跟varchar
	 *
	 * @var array
	 */
	protected $_char_columns=array();

	/**
	 * 自增长字段的名称
	 *
	 * @var string
	 */
	protected $_auto_increment_column='';

	/**
	 * 配置缓存,只支持二级,每一级只支持一种缓存,即是不能在同一级支持多个缓存
	 * 如果是一级缓存则写为array('user_id'=>1)
	 *多级缓存用法,比如相册表,可以分成两级,一级用户,第二级相册专辑,写为array('user_id'=>array('album_id'=>1))
	 * @var array
	 */
	protected $_cache_type=array('single'=>true/*以主键的单条记录*/,'complex'=>false/*所有的杂项查询*/,'multiple'=>array()/*多级缓存*/);

	public function __construct()
	{
		$this->_conn_manager=DBConnections::getInstance();
	}

	public function __destruct()
	{

	}

	/**
	 * 添加观察者对象
	 *
	 * @param IModelObserver $obj
	 */
	public static function  addModelObserver(IModelObserver $obj)
	{
		$model_observer_key='model_observer';
		$register=Registry::getInstance();//从注册模式对象中获取所需要的观察者
		if($register->isRegisted($model_observer_key))
		{
			$observers=$register->get($model_observer_key);
		}
		else
		{
			$observers=array();
		}
		$observers[]=$obj;
		$register->set($model_observer_key,$observers,true);
	}


	/**
	 * 获取所有的观察者对象数组
	 *
	 * @return array
	 */
	protected  function getModelObservers()
	{
		$model_observer_key='model_observer';
		$register=Registry::getInstance();
		if($register->isRegisted($model_observer_key))
		{
			$observers=$register->get($model_observer_key);
		}
		else
		{
			$observers=array();
		}
		return $observers;
	}


	/**
	 * 如果不传递参数，则表示连接的是不分库
	 *
	 * @param int $type
	 * @param $is_select  是否是查询语句
	 */
	public function setFarmId($type=null,$is_select=false)
	{

		if(is_null($this->_farm_field))
		{
			$this->_farm_id=null;
			$this->_cur_db_conn=$this->_conn_manager->getPDO($this->_database_name,!$is_select);
		}
		else
		{
			if(is_null($type))
			{
				throw new Exception("请设置分库字段的值");
			}
			if(is_array($this->_farm_field[key($this->_farm_field)]))
			{
				$this->_farm_id=$type;
			}
			else
			{
				$this->_farm_id=$type%$this->_farm_num;
			}
			$this->_cur_db_conn=$this->_conn_manager->getPDO($this->_database_name.$this->_farm_id,!$is_select);
		}

	}

	/**
	 * 把当前model插入到数据库中，如果有自增长的则返回自增长的值
	 *@param array $duplicate_key  要设置的键值模式
	 * @return int
	 */
	public function insert($duplicate_key=array())
	{
		$column_insert=$this->getAllValues();
		$sql="insert into ".$this->_database_name.$this->_farm_id.".".$this->_table_name;
		if(!empty($column_insert))
		{
			$column_insert=implode(",",$column_insert);

			$sql.=" set ".$column_insert;
		}
		else
		{
			$sql.=" values() ";
		}
		try{
			if(!empty($duplicate_key))
			{
				$duplicate_key_update=array();
				foreach ($duplicate_key as $key=>$value)
				{
					if(!is_null($value)&&array_key_exists($key,$this->_column_types))
					{
						$column_type=$this->_column_types[$key];
						$duplicate_key_update[]=$this->addSlashesColumn($column_type,$key,$value);
					}
				}
				$sql.=" on duplicate key update ".implode(",",$duplicate_key_update);
			}
			$this->log($sql);
			$row_count=$this->_cur_db_conn->exec($sql);
			if($row_count<=0)
			{
				return false;
			}
			else if($this->_have_auto_increment)
			{
				$auto_column=$this->_auto_increment_column;
				$this->$auto_column=$this->_cur_db_conn->lastInsertId();
				$row_count=$this->$auto_column;
			}
			if($row_count>0)
			{
				$observers=$this->getModelObservers();
				for ($i=count($observers)-1;$i>=0;$i--)
				{
					$observers[$i]->onInsert($this->_database_name,$this->_table_name,$this);
				}

				ModelMemcache::getInstance()->clearCacheByInsert($this,$this->innerCacheType(false));
				return $row_count;
			}

		}catch(PDOException $e){
			throw $e;
		}
	}

	/**
	 * 先设置对象的值，即字段要被更改成什么值，注意不能更改为null,然后通过$where来执行。
	 *只能通过where来设置条件,对象的值只有被更改的才能被设置,不然会使相对应的多级缓存过期,甚至整个表缓存过期
	 * @param WhereBuild|mixed $where
	 * @param bool $force_update  where含有字符串赋值,强力清除当前表的所有缓存
	 * @return int
	 */
	public function update($where,$force_update=false)
	{

		$where=$this->buildWhere($where,false,$force_update);
		$where_cache_type=array();
		$update_primary=array();
		if($where!==false)
		{
			$where_cache_type=$where[1];
			$update_primary=$where[2];
			$where=$where[0];

		}
		else
		{
			$where="";
		}
		$column_update=$this->getAllValues();
		$sql="update ".$this->_database_name.$this->_farm_id.".".$this->_table_name;

		if(!empty($column_update))
		{
			$column_update=implode(",",$column_update);
			$sql.=" set ".$column_update;
		}
		else
		{
			return false;
		}





		if(empty($where))
		{
			throw new Exception("不能修改整个表的内容");
		}




		$where=trim($where);
		if(strpos($where,'where')===0)
		{
			$where=substr($where,5);
		}
		$sql.=" where $where";
//var_dump($sql);
		try{
			$this->log($sql);
			$row_count=$this->_cur_db_conn->exec($sql);
			if($row_count>0)
			{
				$observers=$this->getModelObservers();
				for($i=count($observers)-1;$i>=0;$i--)
				{
					$observers[$i]->onUpdate($this->_database_name,$this->_table_name,$update_primary);
				}
				if(!empty($update_primary))
				{
					$sql=$this->cgetByPrimaryKey($update_primary,false,true);

					ModelMemcache::getInstance()->clearCacheByPrimary($update_primary,$this,$where_cache_type,$sql,false);
				}
				else
				{

					ModelMemcache::getInstance()->clearCacheByNormal($this,$where_cache_type);
				}
				$inner_cache_type=$this->innerCacheType(false);
				if(!empty($inner_cache_type)&&!empty($where_cache_type))
				{

					ModelMemcache::getInstance()->clearUpdateCacheType($where_cache_type,$inner_cache_type,$this);
				}
			}
			return $row_count;
		}
		catch(PDOException $e)
		{

			throw $e;
		}
	}

	/**
	 * 删除记录，并返回被删了多少记录
	 *
	 * @param WhereBuild|mixed $where
	 * @param mixed  $farm_field  如果有分库，则传入分库字段的值,如果已经通过对象设置,则不需要再传
	 * @return int
	 */
	public function delete($where,$farm_field=null)
	{
		$delete_primary=array();
		$where=$this->buildWhere($where,false);
		$where_cache_type=array();
		if($where!==false)
		{
			$where_cache_type=$where[1];
			$delete_primary=$where[2];
			$where=$where[0];
		}
		else
		{
			$where="";
		}
		if(empty($where))
		{
			$where=array();
			for($i=count($this->_primary_keys)-1;$i>=0;$i--)
			{
				$key=$this->_primary_keys[$i];
				if(!is_null($this->$key))
				{
					$delete_primary[$key]=$this->$key;
				}
			}
			if(count($delete_primary)!=count($this->_primary_keys))
			{
				$delete_primary=array();
			}
			$where=$this->getAllValues();
			$where_cache_type=$this->innerCacheType(false);
			$where=implode(" and ",$where);
		}
		else
		{
			if(!is_null($farm_field))
			{
				$this->setFarmId($farm_field);
			}
			else if(!is_null($this->_farm_field))
			{
				$farm_field=key($this->_farm_field);
				if(!is_null($this->$farm_field))
				{
					$this->setFarmId($this->$farm_field);
				}
				else
				{
					throw new Exception("请设置分库字段的值");
				}
			}
			else
			{
				$this->setFarmId(null);
			}
		}

		if(empty($where))
		{
			throw new Exception("不能删除整个表的内容");
		}

		$sql="delete from  ".$this->_database_name.$this->_farm_id.".".$this->_table_name;
		$where=trim($where);
		if(strpos($where,'where')===0)
		{
			$where=substr($where,5);
		}
		$sql.=" where $where";
		try{
			$this->log($sql);
			$row_count=$this->_cur_db_conn->exec($sql);
			if($row_count>0)
			{
				$observers=$this->getModelObservers();
				for($i=count($observers)-1;$i>=0;$i--)
				{
					$observers[$i]->onDelete($this->_database_name,$this->_table_name,$delete_primary);
				}
				if(!empty($delete_primary))
				{
					ModelMemcache::getInstance()->clearCacheByPrimary($delete_primary,$this,$where_cache_type,$this->cgetByPrimaryKey($delete_primary,null,true),true);
				}
				else
				{
					ModelMemcache::getInstance()->clearCacheByNormal($this,$where_cache_type);
				}
			}


			return $row_count;

		}catch(PDOException $e){

			throw $e;
		}
	}

	/**
	 * 取得所有要被设置的字段及其值，例如array("'uid'=123","'uname'='dfddf'")
	 *
	 * @return array
	 */
	private function getAllValues()
	{
		$column_values=get_object_vars($this);
		$column_insert=array();
		if($this->_farm_field!=null)
		{
			if(!key_exists(key($this->_farm_field),$column_values))
			{
				throw new Exception("请设置分库字段的值");
			}
			else
			{
				$this->setFarmId($column_values[key($this->_farm_field)]);
			}
		}
		else
		{
			$this->setFarmId(null);
		}
		foreach ($column_values as $key=>$value)
		{
			if(!is_null($value)&&array_key_exists($key,$this->_column_types))
			{
				$column_type=$this->_column_types[$key];
				$column_insert[]=$this->addSlashesColumn($column_type,$key,$value);
			}
		}

		return $column_insert;
	}

	/**
	 * 根据传入的参数生成一个and 的where 语句
	 * @param array $arr_where
	 * @return string
	 */
	protected  function getAndWhere($arr_where=array())
	{
		$where="";
		$arr_where=array_change_key_case($arr_where,CASE_LOWER);
		foreach ($arr_where as $key=>$value)
		{
			if(!is_null($value)&&array_key_exists($key,$this->_column_types))
			{
				$column_type=$this->_column_types[$key];
				$column_insert[]=$this->addSlashesColumn($column_type,$key,$value);
			}
		}
		$where=implode(" and ",$column_insert);
		return $where;
	}

	/**
	 * 从传入的primary key数组来获取相对应的该条记录，并把该对象的相对应属性设值。
	 *
	 * @param array $arr_keys
	 * @param mixed $farm_id
	 * @param bool $is_get_sql
	 * @return boolean|array
	 */
	public function cgetByPrimaryKey($arr_primary_keys,$farm_id=false,$is_get_sql=false)
	{

		$where=$this->getAndWhere($arr_primary_keys);
		if(!$is_get_sql)
		{
			if($this->_farm_field!=null)
			{
				if($farm_id===false)
				{
					throw new Exception("请设置分库字段的值");
				}
				else
				{
					$this->setFarmId($column_values[key($this->_farm_field)],true);
				}
			}
			else
			{
				$this->setFarmId(null,true);
			}
		}
		$columns=array_keys($this->_column_types);
		//$columns=implode(",",$columns);
		$sql="select ".implode(",",$columns)." from ".$this->_database_name.$this->_farm_id.".".$this->_table_name;
		$sql.=" where ".$where;

		if($is_get_sql)
		{
			return $sql;
		}

		//$cache_type=$this->innerCacheType(true);
		$this->log($sql);
		$arr_output=ModelMemcache::getInstance()->get($this,$sql,array(),$arr_primary_keys);
		if(count($arr_output[0])>0)
		{
			foreach ($columns as $key)
			{
				$this->$key=$arr_output[0][$key];
			}
			return  $arr_output[0];
		}
		else
		{
			return null;
		}
	}

	/**
	 * 查找数据
	 *
	 * @param WhereBuild $where  
	 * @param array $columns  数组或是字符串，为空就是全部字段
	 * @param mixed	$farm_id	如果有分库的话就要传递,不能通过设置对象的属性来分库
	 * @return array
	 */
	public function select(WhereBuild $where,$columns=array(),$farm_id=null,$is_count=false)
	{

		$limit=$where->_limit;
		$order="";
		$group="";
		if(!empty($where->_order))
		{
			$order=" order by ";
			foreach ($where->_order as $order_key=>$is_desc)
			{
				$order.=$order_key;
				$order.=$is_desc ? " desc ":" asc ";
				$order.=",";
			}
			$order=substr($order,0,strlen($order)-1);
		}
		if(!empty($where->_group_by))
		{

			$group=" group by ".$where->_group_by['column'];
			if(!empty($where->_group_by['having']))
			{
				$group.=" having ".$where->_group_by['having'];
			}
		}
		$where=$this->buildWhere($where);
		return $this->selectFinal($where,$order,$group,$columns,$farm_id,$is_count,$limit[0],$limit[1]);

	}

	/**
	 * 清除该对象的所有数据，使其等于一个新的对象
	 *
	 */
	public function clearAllData()
	{
		foreach ($this->_column_types as $key=>$value)
		{
			$this->$key=null;
		}
		$this->_cur_db_conn=null;
		$this->_farm_id=null;
	}

	/**
	 * 给需要的字段加上引号
	 *
	 * @param string $column_type
	 * @param string $key
	 * @param mixed $value
	 * @return string
	 */
	protected function addSlashesColumn($column_type,$key,$value)
	{

		if(in_array($column_type,array("tinyint","smallint","mediumint","int","integer","bigint","float","double","dec","decimal","year")))
		{
			if(strpos($value,'--')!==false||strpos($value,'/*')!==false)
			{
				$value=0;
			}
			return "`{$key}`={$value}";
		}
		else if (in_array($column_type,array("date","datetime","timestamp","time"))&&strpos($value,"("))
		{
			return "`{$key}`={$value}";
		}
		else
		{
			return "`{$key}`='{$value}'";
		}
	}

	/**
	 * 把数组里面的值设置为对象的属性,在view里面循环结果集,方便于IDE的自动提示
	 *
	 * @param array $arr
	 */
	public function setDataByArray($arr=array(),$array_key_column_key=array())
	{
		if(!empty($array_key_column_key))
		{
			foreach ($array_key_column_key as $key=>$value)
			{
				if(property_exists($this,$value))
				{
					$this->$value=$arr[$key];
				}
				unset($arr[$key]);
			}
		}
		if(!empty($arr))
		{
			foreach ($arr as $key=>$value)
			{
				if(property_exists($this,$key))
				{
					$this->$key=$value;
				}
			}
		}
	}

	/**
	 * 用来获取字段名或是保护属性的值
	 *
	 * @param string $key
	 * @return mixed
	 */
	public function __get($key)
	{
		if(property_exists($this,$key))
		{
			return $this->$key;
		}
		$key=substr($key,0,strlen($key)-1);
		if(property_exists($this,$key))
		{
			return $key;
		}
		else
		{
			throw new Exception("表{$this->_database_name}.{$this->_table_name} 不存在字段{$key}");
		}
	}

	/**
	 * 
	 *
	 * @param WhereBuild|mixed $where
	 * @param bool $is_select
	 * @param bool $force_update
	 * @return array   array(sql,cache_type=>array())
	 */
	protected function buildWhere($where,$is_select=true,$force_update=false)
	{
		if(is_a($where,'wherebuild'))
		{
			if(empty($where->data))
			{
				return false;
			}
			$where_sql="";
			$where_columns=array();
			$has_or=false;

			for ($i=0,$j=count($where->data);$i<$j;$i++)
			{
				
				if($i>0)
				{
					if($where->data[$i][2])
					{
						$where_sql.=" and ";
					}
					else if(!$is_select&&!$force_update)
					{
						throw  new Exception("更新,删除时不能用or来执行,请采用多次执行来分离");
					}
					else
					{
						
						$where_sql.=" or ";
						
						$has_or=true;
					}
				}
				
				if($where->data[$i][3])
				{
					$where_sql.=" ( ";
				}
				/*if(!$where->data[$i][3]&&!$where->data[$i][2])
				{
				$has_or=true;
				}*/

				if(is_array($where->data[$i][1]))
				{
					$foreach_temp=0;
					foreach ($where->data[$i][1] as $column=>$value)
					{
						if($foreach_temp>0)
						{
							$where_sql.=" ".$where->data[$i][0]." ";
						}
						if($where->data[$i][0]=='or')
						{
							$has_or=true;
						}
						if(is_int($column))
						{
							if(!$is_select&&!$force_update)
							{
								throw  new Exception("更新,删除时不能用字符串,请采用键值模式来赋值");
							}
							$where_sql.=" ".$value;
						}
						else 
						{
							
							$where_sql.=" ".$this->addSlashesColumn($this->_column_types[$column],$column,$value)." ";
							
							if(key_exists($column,$where_columns))
							{
								$where_columns[$column][]=$value;
							}
							else
							{
								$where_columns[$column]=array($value);
							}
						}
						
						$foreach_temp++;
					}
				}
				else if(!$is_select&&!$force_update)
				{
					throw  new Exception("更新,删除时不能用字符串,请采用键值模式来赋值");
				}
				else
				{
					$where_sql.=$where->data[$i][1];
				}


				if($where->data[$i][3])
				{
					$where_sql.=" ) ";
				}
			}
		}
		else if(is_array($where))
		{
			$where_sql=array();
			$where_columns=array();
			$has_or=false;
			if(!empty($where))
			{
				foreach ($where as $key=>$value)
				{
					if(is_int($key))
					{
						if(!$is_select&&!$force_update)
						{
							throw  new Exception("更新,删除时不能用字符串,请采用键值模式来赋值");
						}
						$where_sql[]=$value;
					}
					else
					{
						$where_sql[]=$this->addSlashesColumn($this->_column_types[$key],$key,$value);
						if(key_exists($key,$where_columns))
						{
							$where_columns[$key][]=$value;
						}
						else
						{
							$where_columns[$key]=array($value);
						}
					}
				}
			}
			$where_sql=implode(' and ',$where_sql);
		}
		else
		{
			return false;
		}
		$cache_type=array();

		if(!empty($where_columns)&&!$has_or)
		{
			foreach ($where_columns as $column=>$value)
			{
				$where_columns[$column]=array_unique($value);
			}
			if(!empty($this->_cache_type['multiple']))
			{
				$first_cache=key($this->_cache_type['multiple']);
				if(is_array($this->_cache_type['multiple'][$first_cache]))
				{
					$second_cache=key($this->_cache_type['multiple'][$first_cache]);
					if(key_exists($second_cache,$where_columns)&&!key_exists($first_cache,$where_columns)&&!$is_select)
					{
						throw new Exception("更新,删除时请传入所需的多级缓存的值".var_export($this->_cache_type['multiple'],true));
					}
					else if(count($where_columns[$first_cache])>1&&!$is_select)
					{
						throw new Exception("更新,删除时二级缓存的第一级不能同时传入多个".var_export($this->_cache_type['multiple'],true));
					}
					if(key_exists($first_cache,$where_columns)&&count($where_columns[$first_cache])==1)
					{
						if(key_exists($second_cache,$where_columns)&&count($where_columns[$second_cache])==1)
						{

							$cache_type=array($first_cache=>array($where_columns[$first_cache][0],$second_cache=>$where_columns[$second_cache][0]));
						}
						else
						{
							$cache_type=array($first_cache=>$where_columns[$first_cache][0]);
						}
					}
				}

			}

		}
		$primary_keys=array();
		for($i=count($this->_primary_keys)-1;$i>=0;$i--)
		{
			if(@count($where_columns[$this->_primary_keys[$i]])==1)
			{
				$primary_keys[$this->_primary_keys[$i]]=$where_columns[$this->_primary_keys[$i]][0];
			}
		}
		if(count($this->_primary_keys)!=count($primary_keys))
		{
			$primary_keys=array();
		}
		return array($where_sql,$cache_type,$primary_keys);

	}


	/**
	 * 通过属性来设置值所对应的多级缓存的值是否有设置
	 *@param bool $is_select
	 * @return array
	 */
	protected function innerCacheType($is_select)
	{
		$cache_type=array();
		if(!empty($this->_cache_type['multiple']))
		{
			$first_cache=key($this->_cache_type['multiple']);
			if(is_array($this->_cache_type['multiple'][$first_cache]))
			{
				$second_cache=key($this->_cache_type['multiple'][$first_cache]);
				if(!is_null($this->$second_cache)&&is_null($this->$first_cache)&&!$is_select)
				{
					throw new Exception("更新,删除时请传入所需的多级缓存的值".var_export($this->_cache_type['multiple'],true));
				}

				if(!is_null($this->$first_cache))
				{
					if(!is_null($this->$second_cache))
					{
						$cache_type=array($first_cache=>array($this->$first_cache,$second_cache=>$this->$second_cache));
					}
					else
					{
						$cache_type=array($first_cache=>$this->$first_cache);
					}
				}
			}

		}
		return $cache_type;
	}





	/**
	 * 在控制层进行数据校验调用
	 *
	 * @param array $data
	 * @return bool
	 */
	public function validate($data){
		$_validate = $this->_validate;

		//数据库字段长度指定
		foreach ($this->_char_columns as $key => $value) {
			if (false!==strpos($value,',')) {
				$_validate[$key]['type'] = 'float';
				$_validate[$key]['length'] = empty($_validate[$key]['length']) ? $value : $_validate[$key]['length'];
			} else {
				$_validate[$key]['maxlen'] = empty($_validate[$key]['maxlen']) ? $value : $_validate[$key]['maxlen'];
			}
		}

		foreach ($this->_column_types as $key => $value) {
			if(empty($_validate[$key]['type'])){
				if(in_array($value,array("tinyint","smallint","mediumint","int","integer","bigint","year"))){
					$_validate[$key]['type'] = 'int';
				} elseif(in_array($value,array("float","double","dec","decimal"))) {
					$_validate[$key]['type'] = 'float';
				}
			}
		}

		$validate = new validate($_validate);
		$validate->exec($data);
		return $validate->getError();
	}
	/**
	 * 简单的使用select的方法
	 *
	 * @param array $where
	 * @param string $order 不含有order by的string
	 * @param string $group 不含有group by的string
	 * @param int $limit
	 * @param int $offset
	 * @param mixed $farm_id
	 * @param boolean $is_count
	 * @return array
	 */
	public function selectSimple($where=array(),$columns=array(),$farm_id=null,$is_count=false,$order="",$group="",$limit=0,$offset=0)
	{

		$where=$this->buildWhere($where,true);
		if(!empty($order))
		{
			$order=" order by {$order}";
		}
		if(!empty($group))
		{
			$group=" group by {$group}";
		}

		return $this->selectFinal($where,$order,$group,$columns,$farm_id,$is_count,$limit,$offset);
	}

	/**
	 * 所有的查询的最终调用
	 *
	 * @param array $where array($where_sql,$cache_type,$primary_keys);
	 * @param string $order 含有 order by关键字的字符串
	 * @param string $group 含有group by关键字的字符串
	 * @param array $columns
	 * @param mixed $farm_id
	 * @param boolean $is_count
	 * @param int $limit
	 * @param int $offset
	 * @return array
	 */
	protected function selectFinal($where,$order,$group,$columns,$farm_id,$is_count,$limit=0,$offset=0)
	{

		$where_cache_type=array();
		if($where!==false)
		{
			$where_cache_type=$where[1];
			$where=$where[0];
		}
		else
		{
			$where="";
		}
		if(empty($columns))
		{
			$columns=array_keys($this->_column_types);
			$columns=implode(",",$columns);
		}
		else if(is_array($columns))
		{
			$columns=implode(",",$columns);
		}
		if($this->_farm_field!=null)
		{

			if(is_null($farm_id))
			{
				throw new Exception("请设置分库字段的值");
			}
			else
			{

				$this->setFarmId($farm_id,true);
			}
		}
		else
		{
			$this->setFarmId(null,true);
		}
		if($is_count)
		{
			$columns=" count(*) as c ";
		}
		$sql="select ".$columns." from ".$this->_database_name.$this->_farm_id.".".$this->_table_name;
		if(!empty($where))
		{
			$sql.=" where ".$where;
		}
		
		$sql.=$group."	".$order;
		if(!empty($limit)&&!$is_count)
		{
			$sql.=" limit {$offset} , {$limit}";
		}
		
		$this->log($sql);
		$arr_output=ModelMemcache::getInstance()->get($this,$sql,$where_cache_type);
		//$stmt=$this->_cur_db_conn->query($sql);
		//$arr_output=$stmt->fetchAll(PDO::FETCH_ASSOC);
		return $arr_output;
	}
	
	public function log($sql)
	{
		if(IS_DEBUG)
		{
			$handle=fopen("sql.log","a");
			$sql=date("Y-m-d H:i:s	").$sql."\r\n";
			fwrite($handle,$sql,strlen($sql));
			fclose($handle);
		}
	}

}
